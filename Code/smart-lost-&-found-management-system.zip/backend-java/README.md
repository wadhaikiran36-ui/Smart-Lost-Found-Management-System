# Smart Lost & Found Management System (Java Backend)

## 📌 Project Overview
A complete college-grade full-stack Lost & Found Management System built using Java Servlets, JDBC, MySQL, Apache Tomcat, and a dedicated 7-Criterion Smart Weighted Matching Engine.

---

## 🏗️ Architecture Stack
```
Frontend (HTML5, CSS3, Modern Responsive JavaScript / React UI)
       ↓  (HTTP REST JSON / Session Cookies)
Java Servlets (LoginServlet, LostItemServlet, FoundItemServlet, SearchServlet, MatchServlet, ClaimServlet, AdminServlet)
       ↓
Service Layer (MatchingService, LoginService, UserService, ItemService, ClaimService)
       ↓
DAO Layer (UserDAO, ItemDAO, MatchDAO, ClaimDAO)
       ↓  (JDBC PreparedStatement & Connection Pooling)
MySQL Database (lost_found_system)
```

---

## ⚖️ Smart Matching Algorithm (7 Weighted Criteria)
Implemented in `com.lostfound.service.MatchingService.java`:
1. **Category Match** (20%): Exact match between lost and found item taxonomy.
2. **Item Name Similarity** (20%): Tokenized Jaccard similarity and substring analysis.
3. **Location Similarity** (20%): Proximity and campus zone matching.
4. **Color Match** (10%): Exact or dominant color intersection.
5. **Brand Match** (10%): Non-generic OEM brand comparison.
6. **Date Proximity** (10%): Proximity decay function from 0 to 30 days.
7. **Description Keyword Similarity** (10%): Stop-word-filtered keyword overlap.

**Thresholds:**
- `80% - 100%`: **High Match**
- `60% - 79%`:  **Medium Match**
- `40% - 59%`:  **Low Match**
- `< 40%`:      **Unlikely Match**

---

## 🚀 Quick Setup Instructions

### 1. Database Setup
1. Open MySQL Workbench or MySQL CLI:
   ```bash
   mysql -u root -p
   ```
2. Execute the schema script located at `database/schema.sql`:
   ```sql
   source /path/to/backend-java/database/schema.sql;
   ```
3. Database `lost_found_system` with tables `users`, `admin`, `items`, `matches`, `claims` and sample test records will be initialized.

### 2. Configure Credentials
Update `src/main/webapp/WEB-INF/web.xml` or `DatabaseConnection.java` with your MySQL user and password if different from `root` / `root`.

### 3. Build WAR with Maven
```bash
cd backend-java
mvn clean package
```
This produces `target/lost-found-system.war`.

### 4. Deploy on Apache Tomcat
1. Download Apache Tomcat 9 or 10.
2. Copy `target/lost-found-system.war` to Tomcat's `webapps/` folder.
3. Start Tomcat:
   - Linux/Mac: `./bin/startup.sh`
   - Windows: `bin\startup.bat`
4. Access the application at: `http://localhost:8080/lost-found-system/`

---

## 🔑 Default Test Accounts
- **Admin**: Username: `admin` | Password: `password123`
- **Student 1**: Email: `rahul.sharma@campus.edu` (Student ID: `STU202601`) | Password: `password123`
- **Student 2**: Email: `ananya.patel@campus.edu` (Student ID: `STU202602`) | Password: `password123`
