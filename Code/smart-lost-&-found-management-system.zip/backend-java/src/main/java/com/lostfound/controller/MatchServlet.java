package com.lostfound.controller;

import com.google.gson.Gson;
import com.lostfound.dao.MatchDAO;
import com.lostfound.model.Match;
import com.lostfound.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet providing access to calculated Smart Matches for items.
 * URL Mapping: /api/matches
 */
@WebServlet(name = "MatchServlet", urlPatterns = {"/api/matches"})
public class MatchServlet extends HttpServlet {

    private final MatchDAO matchDAO = new MatchDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            HttpSession session = request.getSession(false);
            String userFilter = request.getParameter("userId");

            List<Match> matches;
            if (userFilter != null && !userFilter.trim().isEmpty()) {
                int uid = Integer.parseInt(userFilter.trim());
                matches = matchDAO.getMatchesForUser(uid);
            } else if (session != null && session.getAttribute("user") != null && !"ADMIN".equals(session.getAttribute("role"))) {
                User user = (User) session.getAttribute("user");
                matches = matchDAO.getMatchesForUser(user.getUserId());
            } else {
                matches = matchDAO.getAllMatches();
            }

            jsonResponse.put("success", true);
            jsonResponse.put("count", matches.size());
            jsonResponse.put("matches", matches);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Error retrieving smart matches: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
