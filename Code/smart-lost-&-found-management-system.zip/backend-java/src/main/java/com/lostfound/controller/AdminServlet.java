package com.lostfound.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lostfound.dao.MatchDAO;
import com.lostfound.model.Student;
import com.lostfound.service.ClaimService;
import com.lostfound.service.ItemService;
import com.lostfound.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet handling administrator dashboard telemetry, moderation, and user management.
 * URL Mapping: /api/admin/dashboard and /api/admin/actions
 */
@WebServlet(name = "AdminServlet", urlPatterns = {"/api/admin/dashboard", "/api/admin/actions"})
public class AdminServlet extends HttpServlet {

    private final UserService userService = new UserService();
    private final ItemService itemService = new ItemService();
    private final ClaimService claimService = new ClaimService();
    private final MatchDAO matchDAO = new MatchDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            // Aggregate telemetry statistics for Admin Dashboard
            int totalUsers = userService.getStudentCount();
            int lostItems = itemService.countByType("LOST");
            int foundItems = itemService.countByType("FOUND");
            int pendingClaims = claimService.countPendingClaims();
            int successfulReturns = itemService.countByStatus("RETURNED");
            int possibleMatches = matchDAO.countPossibleMatches();

            Map<String, Integer> stats = new HashMap<>();
            stats.put("totalUsers", totalUsers);
            stats.put("lostItems", lostItems);
            stats.put("foundItems", foundItems);
            stats.put("pendingClaims", pendingClaims);
            stats.put("successfulReturns", successfulReturns);
            stats.put("possibleMatches", possibleMatches);

            List<Student> usersList = userService.getAllStudents();
            List<com.lostfound.model.Item> allItems = itemService.getAllItems();
            List<com.lostfound.model.Claim> allClaims = claimService.getAllClaims();

            jsonResponse.put("success", true);
            jsonResponse.put("stats", stats);
            jsonResponse.put("users", usersList);
            jsonResponse.put("items", allItems);
            jsonResponse.put("claims", allClaims);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Error loading admin telemetry: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            BufferedReader reader = request.getReader();
            JsonObject payload = JsonParser.parseReader(reader).getAsJsonObject();

            String action = payload.get("action").getAsString();

            switch (action) {
                case "DELETE_ITEM": {
                    int itemId = payload.get("itemId").getAsInt();
                    boolean deleted = itemService.deleteItem(itemId);
                    jsonResponse.put("success", deleted);
                    jsonResponse.put("message", deleted ? "Item removed successfully." : "Item could not be deleted.");
                    break;
                }
                case "UPDATE_ITEM_STATUS": {
                    int itemId = payload.get("itemId").getAsInt();
                    String status = payload.get("status").getAsString(); // APPROVED, RETURNED, REJECTED
                    boolean updated = itemService.updateStatus(itemId, status);
                    jsonResponse.put("success", updated);
                    jsonResponse.put("message", "Item status updated to " + status);
                    break;
                }
                case "DELETE_USER": {
                    int userId = payload.get("userId").getAsInt();
                    boolean deleted = userService.deleteUser(userId);
                    jsonResponse.put("success", deleted);
                    jsonResponse.put("message", deleted ? "User account removed." : "Failed to delete user.");
                    break;
                }
                default:
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "Unrecognized admin action: " + action);
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Admin operation error: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
