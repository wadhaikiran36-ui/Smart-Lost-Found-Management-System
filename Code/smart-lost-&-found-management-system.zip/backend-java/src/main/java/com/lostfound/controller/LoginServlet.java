package com.lostfound.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lostfound.model.Admin;
import com.lostfound.model.Student;
import com.lostfound.service.LoginService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet controller handling user and administrator login and session management.
 * URL Mapping: /api/login and /api/logout
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/api/login", "/api/logout", "/api/auth/status"})
public class LoginServlet extends HttpServlet {

    private final LoginService loginService = new LoginService();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        String path = request.getServletPath();

        // Logout handling
        if ("/api/logout".equals(path)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            jsonResponse.put("success", true);
            jsonResponse.put("message", "Logged out successfully.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        // Login handling
        try {
            BufferedReader reader = request.getReader();
            JsonObject payload = JsonParser.parseReader(reader).getAsJsonObject();

            String identifier = payload.has("identifier") ? payload.get("identifier").getAsString() : "";
            String password = payload.has("password") ? payload.get("password").getAsString() : "";
            String role = payload.has("role") ? payload.get("role").getAsString() : "STUDENT";

            if ("ADMIN".equalsIgnoreCase(role)) {
                Admin admin = loginService.loginAdmin(identifier, password);
                if (admin != null) {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("user", admin);
                    session.setAttribute("role", "ADMIN");

                    jsonResponse.put("success", true);
                    jsonResponse.put("message", "Admin login successful.");
                    jsonResponse.put("user", admin);
                    jsonResponse.put("role", "ADMIN");
                } else {
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "Invalid administrator credentials.");
                }
            } else {
                Student student = loginService.loginStudent(identifier, password);
                if (student != null) {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("user", student);
                    session.setAttribute("role", "STUDENT");

                    jsonResponse.put("success", true);
                    jsonResponse.put("message", "Student login successful.");
                    jsonResponse.put("user", student);
                    jsonResponse.put("role", "STUDENT");
                } else {
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "Invalid Email/Student ID or Password.");
                }
            }
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Database or internal server error: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            jsonResponse.put("authenticated", true);
            jsonResponse.put("user", session.getAttribute("user"));
            jsonResponse.put("role", session.getAttribute("role"));
        } else {
            jsonResponse.put("authenticated", false);
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
