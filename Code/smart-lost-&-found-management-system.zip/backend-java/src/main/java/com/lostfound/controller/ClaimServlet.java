package com.lostfound.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lostfound.model.Claim;
import com.lostfound.model.User;
import com.lostfound.service.ClaimService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet handling submission, retrieval, and updates of Claims.
 * URL Mapping: /api/claims
 */
@WebServlet(name = "ClaimServlet", urlPatterns = {"/api/claims", "/api/claims/review"})
public class ClaimServlet extends HttpServlet {

    private final ClaimService claimService = new ClaimService();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        String path = request.getServletPath();

        try {
            BufferedReader reader = request.getReader();
            JsonObject payload = JsonParser.parseReader(reader).getAsJsonObject();

            // Claim Review by Admin
            if ("/api/claims/review".equals(path)) {
                int claimId = payload.get("claimId").getAsInt();
                int itemId = payload.get("itemId").getAsInt();
                String status = payload.get("status").getAsString(); // APPROVED, REJECTED

                boolean ok = claimService.reviewClaim(claimId, itemId, status);
                if (ok) {
                    jsonResponse.put("success", true);
                    jsonResponse.put("message", "Claim status updated to: " + status);
                } else {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    jsonResponse.put("success", false);
                    jsonResponse.put("message", "Failed to update claim status.");
                }
                out.print(gson.toJson(jsonResponse));
                return;
            }

            // New Claim Submission
            HttpSession session = request.getSession(false);
            int claimantId = 1;
            if (session != null && session.getAttribute("user") != null) {
                User u = (User) session.getAttribute("user");
                claimantId = u.getUserId();
            }
            if (payload.has("claimantId")) {
                claimantId = payload.get("claimantId").getAsInt();
            }

            Claim claim = new Claim();
            claim.setItemId(payload.get("itemId").getAsInt());
            claim.setClaimantId(claimantId);
            claim.setMessage(payload.get("message").getAsString());

            int claimId = claimService.submitClaim(claim);
            response.setStatus(HttpServletResponse.SC_CREATED);
            jsonResponse.put("success", true);
            jsonResponse.put("message", "Claim submitted for administrator review.");
            jsonResponse.put("claimId", claimId);

        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Error handling claim: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            HttpSession session = request.getSession(false);
            String userParam = request.getParameter("claimantId");

            List<Claim> claims;
            if (userParam != null && !userParam.trim().isEmpty()) {
                claims = claimService.getClaimsByClaimant(Integer.parseInt(userParam.trim()));
            } else if (session != null && session.getAttribute("user") != null && !"ADMIN".equals(session.getAttribute("role"))) {
                User u = (User) session.getAttribute("user");
                claims = claimService.getClaimsByClaimant(u.getUserId());
            } else {
                claims = claimService.getAllClaims();
            }

            jsonResponse.put("success", true);
            jsonResponse.put("count", claims.size());
            jsonResponse.put("claims", claims);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
