package com.lostfound.model;

/**
 * Student model extending User.
 * Demonstrates Inheritance and Polymorphism.
 */
public class Student extends User {
    private static final long serialVersionUID = 1L;

    private String studentId;

    public Student() {
        super();
        this.role = "STUDENT";
    }

    public Student(int userId, String name, String studentId, String email, String phone, String password) {
        super(userId, name, email, phone, password, "STUDENT");
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    @Override
    public String getUserIdentifier() {
        return "Student ID: " + this.studentId;
    }
}
