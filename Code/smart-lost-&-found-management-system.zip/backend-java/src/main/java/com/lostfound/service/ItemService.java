package com.lostfound.service;

import com.lostfound.dao.ItemDAO;
import com.lostfound.model.Item;
import com.lostfound.model.Match;
import com.lostfound.util.ValidationUtil;

import java.sql.SQLException;
import java.util.List;

/**
 * Service managing item submissions, updates, filtering, and triggering Smart Matching.
 */
public class ItemService {

    private final ItemDAO itemDAO;
    private final MatchingService matchingService;

    public ItemService() {
        this.itemDAO = new ItemDAO();
        this.matchingService = new MatchingService();
    }

    public ItemService(ItemDAO itemDAO, MatchingService matchingService) {
        this.itemDAO = itemDAO;
        this.matchingService = matchingService;
    }

    /**
     * Submits a new lost or found item report, validates fields, and triggers Smart Matching.
     */
    public List<Match> reportItem(Item item) throws SQLException, IllegalArgumentException {
        validateItem(item);

        int itemId = itemDAO.createItem(item);
        item.setItemId(itemId);

        // Run smart matching against opposite pool
        return matchingService.processItemMatching(item);
    }

    public Item getItemById(int itemId) throws SQLException {
        return itemDAO.getItemById(itemId);
    }

    public List<Item> getAllItems() throws SQLException {
        return itemDAO.getAllItems();
    }

    public List<Item> getItemsByType(String itemType) throws SQLException {
        return itemDAO.getItemsByType(itemType);
    }

    public List<Item> getItemsByUser(int userId) throws SQLException {
        return itemDAO.getItemsByUser(userId);
    }

    public List<Item> searchItems(String keyword, String category, String location, String color, String brand, String itemType) throws SQLException {
        return itemDAO.searchItems(keyword, category, location, color, brand, itemType);
    }

    public boolean updateStatus(int itemId, String status) throws SQLException {
        return itemDAO.updateStatus(itemId, status);
    }

    public boolean deleteItem(int itemId) throws SQLException {
        return itemDAO.deleteItem(itemId);
    }

    public int countByType(String type) throws SQLException {
        return itemDAO.countByType(type);
    }

    public int countByStatus(String status) throws SQLException {
        return itemDAO.countByStatus(status);
    }

    private void validateItem(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Item payload cannot be null.");
        }
        if (ValidationUtil.isEmpty(item.getItemName())) {
            throw new IllegalArgumentException("Item name is required.");
        }
        if (ValidationUtil.isEmpty(item.getCategory())) {
            throw new IllegalArgumentException("Category selection is required.");
        }
        if (ValidationUtil.isEmpty(item.getColor())) {
            throw new IllegalArgumentException("Color specification is required.");
        }
        if (ValidationUtil.isEmpty(item.getLocation())) {
            throw new IllegalArgumentException("Location is required.");
        }
        if (item.getItemDate() == null) {
            throw new IllegalArgumentException("Incident date is required.");
        }
        if (ValidationUtil.isEmpty(item.getDescription())) {
            throw new IllegalArgumentException("Detailed item description is required.");
        }
    }
}
