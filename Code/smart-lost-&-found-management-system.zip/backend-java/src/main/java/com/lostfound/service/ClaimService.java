package com.lostfound.service;

import com.lostfound.dao.ClaimDAO;
import com.lostfound.dao.ItemDAO;
import com.lostfound.model.Claim;
import com.lostfound.util.ValidationUtil;

import java.sql.SQLException;
import java.util.List;

/**
 * Service managing ownership claims submitted by students and adjudicated by administrators.
 */
public class ClaimService {

    private final ClaimDAO claimDAO;
    private final ItemDAO itemDAO;

    public ClaimService() {
        this.claimDAO = new ClaimDAO();
        this.itemDAO = new ItemDAO();
    }

    public ClaimService(ClaimDAO claimDAO, ItemDAO itemDAO) {
        this.claimDAO = claimDAO;
        this.itemDAO = itemDAO;
    }

    public int submitClaim(Claim claim) throws SQLException, IllegalArgumentException {
        if (claim == null) {
            throw new IllegalArgumentException("Claim details cannot be empty.");
        }
        if (claim.getItemId() <= 0) {
            throw new IllegalArgumentException("Invalid target item ID.");
        }
        if (claim.getClaimantId() <= 0) {
            throw new IllegalArgumentException("Claimant must be authenticated.");
        }
        if (ValidationUtil.isEmpty(claim.getMessage()) || claim.getMessage().trim().length() < 10) {
            throw new IllegalArgumentException("Please provide verification proof details (at least 10 characters).");
        }

        return claimDAO.createClaim(claim);
    }

    public List<Claim> getAllClaims() throws SQLException {
        return claimDAO.getAllClaims();
    }

    public List<Claim> getClaimsByClaimant(int claimantId) throws SQLException {
        return claimDAO.getClaimsByClaimant(claimantId);
    }

    public boolean reviewClaim(int claimId, int itemId, String newStatus) throws SQLException {
        boolean updated = claimDAO.updateClaimStatus(claimId, newStatus);
        if (updated && "APPROVED".equalsIgnoreCase(newStatus)) {
            // Mark item as CLAIMED or RETURNED
            itemDAO.updateStatus(itemId, "RETURNED");
        }
        return updated;
    }

    public int countPendingClaims() throws SQLException {
        return claimDAO.countPendingClaims();
    }
}
