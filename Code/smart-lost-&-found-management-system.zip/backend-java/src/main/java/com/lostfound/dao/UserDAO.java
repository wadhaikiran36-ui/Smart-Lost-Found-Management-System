package com.lostfound.dao;

import com.lostfound.model.Admin;
import com.lostfound.model.Student;
import com.lostfound.model.User;
import com.lostfound.util.DatabaseConnection;
import com.lostfound.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User entities (Student, Admin).
 * Uses PreparedStatement for secure, SQL-injection resilient database operations.
 */
public class UserDAO {

    public boolean registerStudent(Student student) throws SQLException {
        String sql = "INSERT INTO users (name, student_id, email, phone, password, role) VALUES (?, ?, ?, ?, ?, 'STUDENT')";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getStudentId());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getPhone());
            stmt.setString(5, PasswordUtil.hashPassword(student.getPassword()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    student.setUserId(rs.getInt(1));
                }
                return true;
            }
            return false;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public Student authenticateStudent(String identifier, String rawPassword) throws SQLException {
        String sql = "SELECT * FROM users WHERE (email = ? OR student_id = ?) AND role = 'STUDENT'";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, identifier);
            stmt.setString(2, identifier);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");
                if (PasswordUtil.verifyPassword(rawPassword, storedHash)) {
                    Student student = new Student();
                    student.setUserId(rs.getInt("user_id"));
                    student.setName(rs.getString("name"));
                    student.setStudentId(rs.getString("student_id"));
                    student.setEmail(rs.getString("email"));
                    student.setPhone(rs.getString("phone"));
                    student.setRole(rs.getString("role"));
                    student.setCreatedAt(rs.getTimestamp("created_at"));
                    return student;
                }
            }
            return null;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public Admin authenticateAdmin(String username, String rawPassword) throws SQLException {
        String sql = "SELECT * FROM admin WHERE username = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");
                if (PasswordUtil.verifyPassword(rawPassword, storedHash)) {
                    Admin admin = new Admin();
                    admin.setAdminId(rs.getInt("admin_id"));
                    admin.setUserId(rs.getInt("admin_id"));
                    admin.setUsername(rs.getString("username"));
                    admin.setName(rs.getString("full_name"));
                    admin.setEmail(rs.getString("email"));
                    admin.setRole("ADMIN");
                    admin.setCreatedAt(rs.getTimestamp("created_at"));
                    return admin;
                }
            }
            return null;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean emailExists(String email) throws SQLException {
        String sql = "SELECT user_id FROM users WHERE email = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            rs = stmt.executeQuery();
            return rs.next();
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean studentIdExists(String studentId) throws SQLException {
        String sql = "SELECT user_id FROM users WHERE student_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentId);
            rs = stmt.executeQuery();
            return rs.next();
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT user_id, name, student_id, email, phone, role, created_at FROM users ORDER BY created_at DESC";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Student s = new Student();
                s.setUserId(rs.getInt("user_id"));
                s.setName(rs.getString("name"));
                s.setStudentId(rs.getString("student_id"));
                s.setEmail(rs.getString("email"));
                s.setPhone(rs.getString("phone"));
                s.setRole(rs.getString("role"));
                s.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(s);
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public int countStudents() throws SQLException {
        String sql = "SELECT COUNT(*) FROM users";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            return rs.next() ? rs.getInt(1) : 0;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean deleteUser(int userId) throws SQLException {
        String sql = "DELETE FROM users WHERE user_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    public boolean updateProfile(int userId, String name, String phone) throws SQLException {
        String sql = "UPDATE users SET name = ?, phone = ? WHERE user_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, phone);
            stmt.setInt(3, userId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }
}
