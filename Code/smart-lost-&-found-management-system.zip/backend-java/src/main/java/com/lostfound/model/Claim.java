package com.lostfound.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a Claim filed by a student for an item.
 */
public class Claim implements Serializable {
    private static final long serialVersionUID = 1L;

    private int claimId;
    private int itemId;
    private int claimantId;
    private String message;
    private String status; // PENDING, APPROVED, REJECTED
    private Timestamp createdAt;

    // Display fields
    private String itemName;
    private String itemType;
    private String claimantName;
    private String claimantEmail;
    private String claimantStudentId;

    public Claim() {
    }

    public Claim(int claimId, int itemId, int claimantId, String message, String status) {
        this.claimId = claimId;
        this.itemId = itemId;
        this.claimantId = claimantId;
        this.message = message;
        this.status = status;
    }

    // Getters and Setters
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getClaimantId() {
        return claimantId;
    }

    public void setClaimantId(int claimantId) {
        this.claimantId = claimantId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getClaimantName() {
        return claimantName;
    }

    public void setClaimantName(String claimantName) {
        this.claimantName = claimantName;
    }

    public String getClaimantEmail() {
        return claimantEmail;
    }

    public void setClaimantEmail(String claimantEmail) {
        this.claimantEmail = claimantEmail;
    }

    public String getClaimantStudentId() {
        return claimantStudentId;
    }

    public void setClaimantStudentId(String claimantStudentId) {
        this.claimantStudentId = claimantStudentId;
    }
}
