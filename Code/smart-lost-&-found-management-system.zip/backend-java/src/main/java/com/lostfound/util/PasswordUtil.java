package com.lostfound.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility for hashing and verifying user passwords using SHA-256 with application salt.
 * Ensures passwords are never stored in plain text.
 */
public class PasswordUtil {

    private static final String APP_SALT = "LostFoundCampus2026@SecuritySalt";

    /**
     * Hashes plain text password with SHA-256 and internal salt.
     * @param plainPassword Raw user password
     * @return Hex-encoded 64-character hash string
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null) {
            return null;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String salted = APP_SALT + plainPassword;
            byte[] encodedHash = digest.digest(salted.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 cryptographic algorithm unavailable", e);
        }
    }

    /**
     * Verifies whether plain input matches the stored salted hash.
     */
    public static boolean verifyPassword(String plainPassword, String storedHash) {
        if (plainPassword == null || storedHash == null) {
            return false;
        }
        String calculatedHash = hashPassword(plainPassword);
        return calculatedHash.equalsIgnoreCase(storedHash);
    }
}
