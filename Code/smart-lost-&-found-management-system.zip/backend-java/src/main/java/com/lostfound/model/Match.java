package com.lostfound.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Model representing a Smart Match result between a Lost Item and a Found Item.
 */
public class Match implements Serializable {
    private static final long serialVersionUID = 1L;

    private int matchId;
    private int lostItemId;
    private int foundItemId;
    private double matchScore; // Percentage 0.0 - 100.0
    private String matchStatus; // PENDING, VERIFIED, DISMISSED
    private Timestamp createdAt;

    // Associated item details for frontend presentation
    private Item lostItem;
    private Item foundItem;
    private List<String> matchedFields = new ArrayList<>();
    private String matchCategory; // High Match, Medium Match, Low Match, Unlikely Match

    public Match() {
    }

    public Match(int matchId, int lostItemId, int foundItemId, double matchScore, String matchStatus) {
        this.matchId = matchId;
        this.lostItemId = lostItemId;
        this.foundItemId = foundItemId;
        this.matchScore = matchScore;
        this.matchStatus = matchStatus;
        evaluateCategory();
    }

    public void evaluateCategory() {
        if (matchScore >= 80.0) {
            this.matchCategory = "High Match";
        } else if (matchScore >= 60.0) {
            this.matchCategory = "Medium Match";
        } else if (matchScore >= 40.0) {
            this.matchCategory = "Low Match";
        } else {
            this.matchCategory = "Unlikely Match";
        }
    }

    // Getters and Setters
    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public int getLostItemId() {
        return lostItemId;
    }

    public void setLostItemId(int lostItemId) {
        this.lostItemId = lostItemId;
    }

    public int getFoundItemId() {
        return foundItemId;
    }

    public void setFoundItemId(int foundItemId) {
        this.foundItemId = foundItemId;
    }

    public double getMatchScore() {
        return matchScore;
    }

    public void setMatchScore(double matchScore) {
        this.matchScore = matchScore;
        evaluateCategory();
    }

    public String getMatchStatus() {
        return matchStatus;
    }

    public void setMatchStatus(String matchStatus) {
        this.matchStatus = matchStatus;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Item getLostItem() {
        return lostItem;
    }

    public void setLostItem(Item lostItem) {
        this.lostItem = lostItem;
    }

    public Item getFoundItem() {
        return foundItem;
    }

    public void setFoundItem(Item foundItem) {
        this.foundItem = foundItem;
    }

    public List<String> getMatchedFields() {
        return matchedFields;
    }

    public void setMatchedFields(List<String> matchedFields) {
        this.matchedFields = matchedFields;
    }

    public void addMatchedField(String field) {
        if (this.matchedFields == null) {
            this.matchedFields = new ArrayList<>();
        }
        this.matchedFields.add(field);
    }

    public String getMatchCategory() {
        if (matchCategory == null) {
            evaluateCategory();
        }
        return matchCategory;
    }

    public void setMatchCategory(String matchCategory) {
        this.matchCategory = matchCategory;
    }
}
