package com.lostfound.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lostfound.model.Student;
import com.lostfound.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet handling new student registration.
 * URL Mapping: /api/register
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/api/register"})
public class RegisterServlet extends HttpServlet {

    private final UserService userService = new UserService();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            BufferedReader reader = request.getReader();
            JsonObject payload = JsonParser.parseReader(reader).getAsJsonObject();

            String name = payload.has("name") ? payload.get("name").getAsString() : "";
            String studentId = payload.has("studentId") ? payload.get("studentId").getAsString() : "";
            String email = payload.has("email") ? payload.get("email").getAsString() : "";
            String phone = payload.has("phone") ? payload.get("phone").getAsString() : "";
            String password = payload.has("password") ? payload.get("password").getAsString() : "";
            String confirmPassword = payload.has("confirmPassword") ? payload.get("confirmPassword").getAsString() : "";

            if (!password.equals(confirmPassword)) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Password and Confirm Password do not match.");
                out.print(gson.toJson(jsonResponse));
                return;
            }

            Student student = new Student();
            student.setName(name);
            student.setStudentId(studentId);
            student.setEmail(email);
            student.setPhone(phone);
            student.setPassword(password);

            boolean success = userService.registerStudent(student);
            if (success) {
                response.setStatus(HttpServletResponse.SC_CREATED);
                jsonResponse.put("success", true);
                jsonResponse.put("message", "Student registration completed successfully.");
                jsonResponse.put("userId", student.getUserId());
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.put("success", false);
                jsonResponse.put("message", "Registration failed. Please verify submitted details.");
            }
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Error during registration: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
