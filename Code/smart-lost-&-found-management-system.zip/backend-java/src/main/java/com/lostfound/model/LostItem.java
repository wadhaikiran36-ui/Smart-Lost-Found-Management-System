package com.lostfound.model;

import java.sql.Date;

/**
 * Subclass representing a Lost Item.
 * Demonstrates Inheritance and Polymorphic method implementation.
 */
public class LostItem extends Item {
    private static final long serialVersionUID = 1L;

    public LostItem() {
        super();
        this.itemType = "LOST";
    }

    public LostItem(int itemId, int userId, String itemName, String category,
                    String color, String brand, String description, String location,
                    Date itemDate, String imagePath, String status) {
        super(itemId, userId, "LOST", itemName, category, color, brand, description, location, itemDate, imagePath, status);
    }

    @Override
    public String getReportSummary() {
        return "[LOST REPORT] " + itemName + " (" + category + ") lost at " + location + " on " + itemDate;
    }
}
