package com.lostfound.model;

import java.sql.Date;

/**
 * Subclass representing a Found Item.
 * Demonstrates Inheritance and Polymorphic method implementation.
 */
public class FoundItem extends Item {
    private static final long serialVersionUID = 1L;

    public FoundItem() {
        super();
        this.itemType = "FOUND";
    }

    public FoundItem(int itemId, int userId, String itemName, String category,
                     String color, String brand, String description, String location,
                     Date itemDate, String imagePath, String status) {
        super(itemId, userId, "FOUND", itemName, category, color, brand, description, location, itemDate, imagePath, status);
    }

    @Override
    public String getReportSummary() {
        return "[FOUND REPORT] " + itemName + " (" + category + ") found at " + location + " on " + itemDate;
    }
}
