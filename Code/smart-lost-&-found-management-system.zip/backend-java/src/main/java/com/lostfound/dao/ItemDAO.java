package com.lostfound.dao;

import com.lostfound.model.FoundItem;
import com.lostfound.model.Item;
import com.lostfound.model.LostItem;
import com.lostfound.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Item entities (LostItem and FoundItem).
 * Handles CRUD operations, filtering, and database search queries.
 */
public class ItemDAO {

    public int createItem(Item item) throws SQLException {
        String sql = "INSERT INTO items (user_id, item_type, item_name, category, color, brand, description, location, item_date, image_path, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, item.getUserId());
            stmt.setString(2, item.getItemType());
            stmt.setString(3, item.getItemName());
            stmt.setString(4, item.getCategory());
            stmt.setString(5, item.getColor());
            stmt.setString(6, item.getBrand() == null ? "Unknown" : item.getBrand());
            stmt.setString(7, item.getDescription());
            stmt.setString(8, item.getLocation());
            stmt.setDate(9, item.getItemDate());
            stmt.setString(10, item.getImagePath());
            stmt.setString(11, item.getStatus() == null ? "APPROVED" : item.getStatus());

            stmt.executeUpdate();
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                item.setItemId(generatedId);
                return generatedId;
            }
            return -1;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public Item getItemById(int itemId) throws SQLException {
        String sql = "SELECT i.*, u.name as reporter_name, u.phone as reporter_phone "
                   + "FROM items i JOIN users u ON i.user_id = u.user_id WHERE i.item_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, itemId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToItem(rs);
            }
            return null;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Item> getAllItems() throws SQLException {
        String sql = "SELECT i.*, u.name as reporter_name, u.phone as reporter_phone "
                   + "FROM items i JOIN users u ON i.user_id = u.user_id ORDER BY i.created_at DESC";
        return executeQueryToList(sql);
    }

    public List<Item> getItemsByType(String itemType) throws SQLException {
        String sql = "SELECT i.*, u.name as reporter_name, u.phone as reporter_phone "
                   + "FROM items i JOIN users u ON i.user_id = u.user_id WHERE i.item_type = ? ORDER BY i.created_at DESC";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Item> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, itemType);
            rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(mapResultSetToItem(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Item> getItemsByUser(int userId) throws SQLException {
        String sql = "SELECT i.*, u.name as reporter_name, u.phone as reporter_phone "
                   + "FROM items i JOIN users u ON i.user_id = u.user_id WHERE i.user_id = ? ORDER BY i.created_at DESC";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Item> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(mapResultSetToItem(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Item> searchItems(String keyword, String category, String location, String color, String brand, String itemType) throws SQLException {
        StringBuilder sql = new StringBuilder(
            "SELECT i.*, u.name as reporter_name, u.phone as reporter_phone " +
            "FROM items i JOIN users u ON i.user_id = u.user_id WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (i.item_name LIKE ? OR i.description LIKE ? OR i.location LIKE ?) ");
            String kw = "%" + keyword.trim() + "%";
            params.add(kw);
            params.add(kw);
            params.add(kw);
        }
        if (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) {
            sql.append("AND i.category = ? ");
            params.add(category.trim());
        }
        if (location != null && !location.trim().isEmpty()) {
            sql.append("AND i.location LIKE ? ");
            params.add("%" + location.trim() + "%");
        }
        if (color != null && !color.trim().isEmpty()) {
            sql.append("AND i.color LIKE ? ");
            params.add("%" + color.trim() + "%");
        }
        if (brand != null && !brand.trim().isEmpty()) {
            sql.append("AND i.brand LIKE ? ");
            params.add("%" + brand.trim() + "%");
        }
        if (itemType != null && !itemType.trim().isEmpty() && !itemType.equalsIgnoreCase("ALL")) {
            sql.append("AND i.item_type = ? ");
            params.add(itemType.trim());
        }

        sql.append("ORDER BY i.created_at DESC");

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Item> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql.toString());
            for (int idx = 0; idx < params.size(); idx++) {
                stmt.setObject(idx + 1, params.get(idx));
            }
            rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(mapResultSetToItem(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean updateStatus(int itemId, String status) throws SQLException {
        String sql = "UPDATE items SET status = ? WHERE item_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setInt(2, itemId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    public boolean deleteItem(int itemId) throws SQLException {
        String sql = "DELETE FROM items WHERE item_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, itemId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    public int countByType(String type) throws SQLException {
        String sql = "SELECT COUNT(*) FROM items WHERE item_type = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, type);
            rs = stmt.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public int countByStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM items WHERE status = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            rs = stmt.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    private List<Item> executeQueryToList(String sql) throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<Item> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                list.add(mapResultSetToItem(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    private Item mapResultSetToItem(ResultSet rs) throws SQLException {
        String type = rs.getString("item_type");
        Item item = "LOST".equalsIgnoreCase(type) ? new LostItem() : new FoundItem();

        item.setItemId(rs.getInt("item_id"));
        item.setUserId(rs.getInt("user_id"));
        item.setItemType(type);
        item.setItemName(rs.getString("item_name"));
        item.setCategory(rs.getString("category"));
        item.setColor(rs.getString("color"));
        item.setBrand(rs.getString("brand"));
        item.setDescription(rs.getString("description"));
        item.setLocation(rs.getString("location"));
        item.setItemDate(rs.getDate("item_date"));
        item.setImagePath(rs.getString("image_path"));
        item.setStatus(rs.getString("status"));
        item.setCreatedAt(rs.getTimestamp("created_at"));
        
        try {
            item.setReporterName(rs.getString("reporter_name"));
            item.setReporterContact(rs.getString("reporter_phone"));
        } catch (SQLException ignored) {
            // Optional joins
        }

        return item;
    }
}
