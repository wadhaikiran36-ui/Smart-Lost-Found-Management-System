package com.lostfound.dao;

import com.lostfound.model.Claim;
import com.lostfound.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Claims table.
 * Manages item ownership verification requests and status updates.
 */
public class ClaimDAO {

    public int createClaim(Claim claim) throws SQLException {
        String sql = "INSERT INTO claims (item_id, claimant_id, message, status) VALUES (?, ?, ?, 'PENDING')";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, claim.getItemId());
            stmt.setInt(2, claim.getClaimantId());
            stmt.setString(3, claim.getMessage());

            stmt.executeUpdate();
            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                claim.setClaimId(generatedId);
                return generatedId;
            }
            return -1;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Claim> getAllClaims() throws SQLException {
        String sql = "SELECT c.*, i.item_name, i.item_type, u.name as claimant_name, u.email as claimant_email, u.student_id as claimant_student_id "
                   + "FROM claims c "
                   + "JOIN items i ON c.item_id = i.item_id "
                   + "JOIN users u ON c.claimant_id = u.user_id "
                   + "ORDER BY c.created_at DESC";

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<Claim> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                list.add(mapResultSetToClaim(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Claim> getClaimsByClaimant(int claimantId) throws SQLException {
        String sql = "SELECT c.*, i.item_name, i.item_type, u.name as claimant_name, u.email as claimant_email, u.student_id as claimant_student_id "
                   + "FROM claims c "
                   + "JOIN items i ON c.item_id = i.item_id "
                   + "JOIN users u ON c.claimant_id = u.user_id "
                   + "WHERE c.claimant_id = ? "
                   + "ORDER BY c.created_at DESC";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Claim> list = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, claimantId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(mapResultSetToClaim(rs));
            }
            return list;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean updateClaimStatus(int claimId, String status) throws SQLException {
        String sql = "UPDATE claims SET status = ? WHERE claim_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setInt(2, claimId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    public int countPendingClaims() throws SQLException {
        String sql = "SELECT COUNT(*) FROM claims WHERE status = 'PENDING'";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            return rs.next() ? rs.getInt(1) : 0;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    private Claim mapResultSetToClaim(ResultSet rs) throws SQLException {
        Claim c = new Claim();
        c.setClaimId(rs.getInt("claim_id"));
        c.setItemId(rs.getInt("item_id"));
        c.setClaimantId(rs.getInt("claimant_id"));
        c.setMessage(rs.getString("message"));
        c.setStatus(rs.getString("status"));
        c.setCreatedAt(rs.getTimestamp("created_at"));
        c.setItemName(rs.getString("item_name"));
        c.setItemType(rs.getString("item_type"));
        c.setClaimantName(rs.getString("claimant_name"));
        c.setClaimantEmail(rs.getString("claimant_email"));
        c.setClaimantStudentId(rs.getString("claimant_student_id"));
        return c;
    }
}
