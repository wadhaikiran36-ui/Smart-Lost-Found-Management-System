package com.lostfound.model;

/**
 * Admin model extending User.
 * Demonstrates Inheritance and Polymorphism.
 */
public class Admin extends User {
    private static final long serialVersionUID = 1L;

    private int adminId;
    private String username;

    public Admin() {
        super();
        this.role = "ADMIN";
    }

    public Admin(int adminId, String username, String password, String fullName, String email) {
        super(adminId, fullName, email, "", password, "ADMIN");
        this.adminId = adminId;
        this.username = username;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getUserIdentifier() {
        return "Admin Username: " + this.username;
    }
}
