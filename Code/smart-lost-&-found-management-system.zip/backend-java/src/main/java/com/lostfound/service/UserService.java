package com.lostfound.service;

import com.lostfound.dao.UserDAO;
import com.lostfound.model.Student;
import com.lostfound.util.ValidationUtil;

import java.sql.SQLException;
import java.util.List;

/**
 * Service managing Student registration and profile updates.
 */
public class UserService {

    private final UserDAO userDAO;

    public UserService() {
        this.userDAO = new UserDAO();
    }

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public boolean registerStudent(Student student) throws SQLException, IllegalArgumentException {
        if (student == null) {
            throw new IllegalArgumentException("Student registration data cannot be null.");
        }
        if (ValidationUtil.isEmpty(student.getName())) {
            throw new IllegalArgumentException("Full name is required.");
        }
        if (!ValidationUtil.isValidStudentId(student.getStudentId())) {
            throw new IllegalArgumentException("Student ID must be 3-20 alphanumeric characters.");
        }
        if (!ValidationUtil.isValidEmail(student.getEmail())) {
            throw new IllegalArgumentException("A valid university email address is required.");
        }
        if (!ValidationUtil.isValidPhone(student.getPhone())) {
            throw new IllegalArgumentException("Phone number must contain between 10 and 15 digits.");
        }
        if (!ValidationUtil.isValidPassword(student.getPassword())) {
            throw new IllegalArgumentException("Password must be at least 6 characters long.");
        }

        // Duplicate checks
        if (userDAO.emailExists(student.getEmail())) {
            throw new IllegalArgumentException("An account with this email address already exists.");
        }
        if (userDAO.studentIdExists(student.getStudentId())) {
            throw new IllegalArgumentException("An account with this student ID already exists.");
        }

        return userDAO.registerStudent(student);
    }

    public List<Student> getAllStudents() throws SQLException {
        return userDAO.getAllStudents();
    }

    public int getStudentCount() throws SQLException {
        return userDAO.countStudents();
    }

    public boolean deleteUser(int userId) throws SQLException {
        return userDAO.deleteUser(userId);
    }

    public boolean updateProfile(int userId, String name, String phone) throws SQLException {
        if (ValidationUtil.isEmpty(name)) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        if (!ValidationUtil.isValidPhone(phone)) {
            throw new IllegalArgumentException("Invalid phone number.");
        }
        return userDAO.updateProfile(userId, name.trim(), phone.trim());
    }
}
