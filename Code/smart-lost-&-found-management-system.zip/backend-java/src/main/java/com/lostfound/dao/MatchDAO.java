package com.lostfound.dao;

import com.lostfound.model.FoundItem;
import com.lostfound.model.Item;
import com.lostfound.model.LostItem;
import com.lostfound.model.Match;
import com.lostfound.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Smart Matches table.
 * Persists calculated similarity scores and provides matching queries for students and admins.
 */
public class MatchDAO {

    public boolean saveOrUpdateMatch(Match match) throws SQLException {
        String sql = "INSERT INTO matches (lost_item_id, found_item_id, match_score, match_status) "
                   + "VALUES (?, ?, ?, ?) "
                   + "ON DUPLICATE KEY UPDATE match_score = VALUES(match_score), match_status = VALUES(match_status)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, match.getLostItemId());
            stmt.setInt(2, match.getFoundItemId());
            stmt.setDouble(3, match.getMatchScore());
            stmt.setString(4, match.getMatchStatus() == null ? "PENDING" : match.getMatchStatus());
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    public List<Match> getAllMatches() throws SQLException {
        String sql = "SELECT m.*, "
                   + "l.item_name as lost_name, l.category as lost_cat, l.location as lost_loc, l.color as lost_color, l.brand as lost_brand, l.item_date as lost_date, l.description as lost_desc, "
                   + "f.item_name as found_name, f.category as found_cat, f.location as found_loc, f.color as found_color, f.brand as found_brand, f.item_date as found_date, f.description as found_desc "
                   + "FROM matches m "
                   + "JOIN items l ON m.lost_item_id = l.item_id "
                   + "JOIN items f ON m.found_item_id = f.item_id "
                   + "ORDER BY m.match_score DESC";

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<Match> matches = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Match m = mapResultSetToMatch(rs);
                matches.add(m);
            }
            return matches;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public List<Match> getMatchesForUser(int userId) throws SQLException {
        String sql = "SELECT m.*, "
                   + "l.item_name as lost_name, l.category as lost_cat, l.location as lost_loc, l.color as lost_color, l.brand as lost_brand, l.item_date as lost_date, l.description as lost_desc, "
                   + "f.item_name as found_name, f.category as found_cat, f.location as found_loc, f.color as found_color, f.brand as found_brand, f.item_date as found_date, f.description as found_desc "
                   + "FROM matches m "
                   + "JOIN items l ON m.lost_item_id = l.item_id "
                   + "JOIN items f ON m.found_item_id = f.item_id "
                   + "WHERE l.user_id = ? OR f.user_id = ? "
                   + "ORDER BY m.match_score DESC";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Match> matches = new ArrayList<>();

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Match m = mapResultSetToMatch(rs);
                matches.add(m);
            }
            return matches;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public int countPossibleMatches() throws SQLException {
        String sql = "SELECT COUNT(*) FROM matches WHERE match_score >= 40.0";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            return rs.next() ? rs.getInt(1) : 0;
        } finally {
            DatabaseConnection.close(conn, stmt, rs);
        }
    }

    public boolean updateMatchStatus(int matchId, String status) throws SQLException {
        String sql = "UPDATE matches SET match_status = ? WHERE match_id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setInt(2, matchId);
            return stmt.executeUpdate() > 0;
        } finally {
            DatabaseConnection.close(conn, stmt);
        }
    }

    private Match mapResultSetToMatch(ResultSet rs) throws SQLException {
        Match m = new Match();
        m.setMatchId(rs.getInt("match_id"));
        m.setLostItemId(rs.getInt("lost_item_id"));
        m.setFoundItemId(rs.getInt("found_item_id"));
        m.setMatchScore(rs.getDouble("match_score"));
        m.setMatchStatus(rs.getString("match_status"));
        m.setCreatedAt(rs.getTimestamp("created_at"));
        m.evaluateCategory();

        // Build preview lost item
        LostItem lost = new LostItem();
        lost.setItemId(m.getLostItemId());
        lost.setItemName(rs.getString("lost_name"));
        lost.setCategory(rs.getString("lost_cat"));
        lost.setLocation(rs.getString("lost_loc"));
        lost.setColor(rs.getString("lost_color"));
        lost.setBrand(rs.getString("lost_brand"));
        lost.setItemDate(rs.getDate("lost_date"));
        lost.setDescription(rs.getString("lost_desc"));
        m.setLostItem(lost);

        // Build preview found item
        FoundItem found = new FoundItem();
        found.setItemId(m.getFoundItemId());
        found.setItemName(rs.getString("found_name"));
        found.setCategory(rs.getString("found_cat"));
        found.setLocation(rs.getString("found_loc"));
        found.setColor(rs.getString("found_color"));
        found.setBrand(rs.getString("found_brand"));
        found.setItemDate(rs.getDate("found_date"));
        found.setDescription(rs.getString("found_desc"));
        m.setFoundItem(found);

        return m;
    }
}
