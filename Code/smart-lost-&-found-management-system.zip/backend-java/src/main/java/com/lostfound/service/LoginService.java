package com.lostfound.service;

import com.lostfound.dao.UserDAO;
import com.lostfound.model.Admin;
import com.lostfound.model.Student;
import com.lostfound.model.User;
import com.lostfound.util.ValidationUtil;

import java.sql.SQLException;

/**
 * Service orchestrating Student and Admin authentication.
 */
public class LoginService {

    private final UserDAO userDAO;

    public LoginService() {
        this.userDAO = new UserDAO();
    }

    public LoginService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    /**
     * Authenticates a student via email or student ID.
     */
    public Student loginStudent(String identifier, String password) throws SQLException, IllegalArgumentException {
        if (ValidationUtil.isEmpty(identifier) || ValidationUtil.isEmpty(password)) {
            throw new IllegalArgumentException("Email/Student ID and Password cannot be empty.");
        }
        return userDAO.authenticateStudent(identifier.trim(), password);
    }

    /**
     * Authenticates an administrator via username.
     */
    public Admin loginAdmin(String username, String password) throws SQLException, IllegalArgumentException {
        if (ValidationUtil.isEmpty(username) || ValidationUtil.isEmpty(password)) {
            throw new IllegalArgumentException("Username and Password cannot be empty.");
        }
        return userDAO.authenticateAdmin(username.trim(), password);
    }
}
