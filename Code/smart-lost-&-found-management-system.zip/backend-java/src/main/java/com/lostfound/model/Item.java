package com.lostfound.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * Base Item class representing an inventory item (Lost or Found).
 * Demonstrates Abstraction and Encapsulation.
 */
public abstract class Item implements Serializable {
    private static final long serialVersionUID = 1L;

    protected int itemId;
    protected int userId;
    protected String itemType; // "LOST" or "FOUND"
    protected String itemName;
    protected String category;
    protected String color;
    protected String brand;
    protected String description;
    protected String location;
    protected Date itemDate;
    protected String imagePath;
    protected String status; // "PENDING", "APPROVED", "CLAIMED", "RETURNED", "REJECTED"
    protected Timestamp createdAt;

    // Additional transient display fields
    protected String reporterName;
    protected String reporterContact;

    public Item() {
    }

    public Item(int itemId, int userId, String itemType, String itemName, String category,
                String color, String brand, String description, String location,
                Date itemDate, String imagePath, String status) {
        this.itemId = itemId;
        this.userId = userId;
        this.itemType = itemType;
        this.itemName = itemName;
        this.category = category;
        this.color = color;
        this.brand = brand;
        this.description = description;
        this.location = location;
        this.itemDate = itemDate;
        this.imagePath = imagePath;
        this.status = status;
    }

    // Abstract method implemented by LostItem and FoundItem
    public abstract String getReportSummary();

    // Getters and Setters
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getItemDate() {
        return itemDate;
    }

    public void setItemDate(Date itemDate) {
        this.itemDate = itemDate;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getReporterName() {
        return reporterName;
    }

    public void setReporterName(String reporterName) {
        this.reporterName = reporterName;
    }

    public String getReporterContact() {
        return reporterContact;
    }

    public void setReporterContact(String reporterContact) {
        this.reporterContact = reporterContact;
    }
}
