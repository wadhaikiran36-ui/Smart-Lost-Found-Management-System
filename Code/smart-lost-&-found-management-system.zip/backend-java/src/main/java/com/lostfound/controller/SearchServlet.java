package com.lostfound.controller;

import com.google.gson.Gson;
import com.lostfound.model.Item;
import com.lostfound.service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet handling multi-criteria item searches and filters.
 * URL Mapping: /api/items/search and /api/items
 */
@WebServlet(name = "SearchServlet", urlPatterns = {"/api/items/search", "/api/items"})
public class SearchServlet extends HttpServlet {

    private final ItemService itemService = new ItemService();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            String keyword = request.getParameter("keyword");
            String category = request.getParameter("category");
            String location = request.getParameter("location");
            String color = request.getParameter("color");
            String brand = request.getParameter("brand");
            String itemType = request.getParameter("itemType");

            List<Item> results;
            if (isEmpty(keyword) && isEmpty(category) && isEmpty(location) && isEmpty(color) && isEmpty(brand) && isEmpty(itemType)) {
                results = itemService.getAllItems();
            } else {
                results = itemService.searchItems(keyword, category, location, color, brand, itemType);
            }

            jsonResponse.put("success", true);
            jsonResponse.put("count", results.size());
            jsonResponse.put("items", results);

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Search query error: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty() || "ALL".equalsIgnoreCase(s.trim());
    }
}
