package com.lostfound.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lostfound.model.LostItem;
import com.lostfound.model.Match;
import com.lostfound.model.User;
import com.lostfound.service.ItemService;
import com.lostfound.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet handling reporting and fetching of Lost Items.
 * URL Mapping: /api/items/lost
 */
@WebServlet(name = "LostItemServlet", urlPatterns = {"/api/items/lost"})
public class LostItemServlet extends HttpServlet {

    private final ItemService itemService = new ItemService();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            HttpSession session = request.getSession(false);
            int userId = 1; // Default fallback for anonymous/demo user
            if (session != null && session.getAttribute("user") != null) {
                User user = (User) session.getAttribute("user");
                userId = user.getUserId();
            }

            BufferedReader reader = request.getReader();
            JsonObject payload = JsonParser.parseReader(reader).getAsJsonObject();

            if (payload.has("userId")) {
                userId = payload.get("userId").getAsInt();
            }

            LostItem lost = new LostItem();
            lost.setUserId(userId);
            lost.setItemName(payload.has("itemName") ? payload.get("itemName").getAsString() : "");
            lost.setCategory(payload.has("category") ? payload.get("category").getAsString() : "");
            lost.setColor(payload.has("color") ? payload.get("color").getAsString() : "");
            lost.setBrand(payload.has("brand") ? payload.get("brand").getAsString() : "Unknown");
            lost.setLocation(payload.has("location") ? payload.get("location").getAsString() : "");
            lost.setDescription(payload.has("description") ? payload.get("description").getAsString() : "");
            lost.setItemDate(ValidationUtil.parseDate(payload.has("itemDate") ? payload.get("itemDate").getAsString() : null));
            lost.setImagePath(payload.has("imagePath") ? payload.get("imagePath").getAsString() : null);

            List<Match> generatedMatches = itemService.reportItem(lost);

            response.setStatus(HttpServletResponse.SC_CREATED);
            jsonResponse.put("success", true);
            jsonResponse.put("message", "Lost item report registered successfully.");
            jsonResponse.put("item", lost);
            jsonResponse.put("matchesFound", generatedMatches.size());
            jsonResponse.put("matches", generatedMatches);

        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Failed to register lost item: " + e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> jsonResponse = new HashMap<>();

        try {
            List<com.lostfound.model.Item> items = itemService.getItemsByType("LOST");
            jsonResponse.put("success", true);
            jsonResponse.put("count", items.size());
            jsonResponse.put("items", items);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.put("success", false);
            jsonResponse.put("message", e.getMessage());
        }

        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
