package com.lostfound.service;

import com.lostfound.dao.ItemDAO;
import com.lostfound.dao.MatchDAO;
import com.lostfound.model.Item;
import com.lostfound.model.Match;

import java.sql.Date;
import java.sql.SQLException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Core Smart Matching Engine for Lost & Found items.
 *
 * Implements the 7-Criterion Weighted Scoring System:
 * - Category match:        20%
 * - Item name similarity:  20%
 * - Location similarity:   20%
 * - Color match:           10%
 * - Brand match:           10%
 * - Date proximity:        10%
 * - Description similarity:10%
 * Total = 100%
 *
 * Threshold Categories:
 * - 80-100% -> High Match
 * - 60-79%  -> Medium Match
 * - 40-59%  -> Low Match
 * - Below 40% -> Unlikely Match
 */
public class MatchingService {

    private final ItemDAO itemDAO;
    private final MatchDAO matchDAO;

    public MatchingService() {
        this.itemDAO = new ItemDAO();
        this.matchDAO = new MatchDAO();
    }

    public MatchingService(ItemDAO itemDAO, MatchDAO matchDAO) {
        this.itemDAO = itemDAO;
        this.matchDAO = matchDAO;
    }

    /**
     * Triggered whenever a new item is submitted (or updated).
     * Compares the target item against all existing opposite-type items (LOST vs FOUND, FOUND vs LOST).
     * Computes similarity, generates matched-field badges, and saves significant matches to MySQL.
     *
     * @param targetItem The newly submitted or updated item
     * @return List of generated matches sorted by score descending
     */
    public List<Match> processItemMatching(Item targetItem) throws SQLException {
        String oppositeType = "LOST".equalsIgnoreCase(targetItem.getItemType()) ? "FOUND" : "LOST";
        List<Item> candidates = itemDAO.getItemsByType(oppositeType);
        List<Match> generatedMatches = new ArrayList<>();

        for (Item candidate : candidates) {
            // Determine which is lost and which is found
            Item lost = "LOST".equalsIgnoreCase(targetItem.getItemType()) ? targetItem : candidate;
            Item found = "FOUND".equalsIgnoreCase(targetItem.getItemType()) ? targetItem : candidate;

            Match match = calculateMatch(lost, found);
            
            // Only persist matches with meaningful similarity (>= 40%)
            if (match.getMatchScore() >= 40.0) {
                matchDAO.saveOrUpdateMatch(match);
                generatedMatches.add(match);
            }
        }

        return generatedMatches;
    }

    /**
     * Calculates the weighted similarity score between a Lost Item and a Found Item.
     *
     * @param lost The Lost Item
     * @param found The Found Item
     * @return Match object containing total score, matched fields list, and categorization
     */
    public Match calculateMatch(Item lost, Item found) {
        Match match = new Match();
        match.setLostItemId(lost.getItemId());
        match.setFoundItemId(found.getItemId());
        match.setLostItem(lost);
        match.setFoundItem(found);

        double totalScore = 0.0;
        List<String> matchedBadges = new ArrayList<>();

        // 1. Category Match (20%)
        if (isEqualIgnoreCase(lost.getCategory(), found.getCategory())) {
            totalScore += 20.0;
            matchedBadges.add("Same category (" + lost.getCategory() + ")");
        }

        // 2. Item Name Similarity (20%)
        double nameSim = calculateTextSimilarity(lost.getItemName(), found.getItemName());
        totalScore += (nameSim * 20.0);
        if (nameSim >= 0.6) {
            matchedBadges.add("Similar item name (" + Math.round(nameSim * 100) + "%)");
        }

        // 3. Location Similarity (20%)
        double locSim = calculateTextSimilarity(lost.getLocation(), found.getLocation());
        totalScore += (locSim * 20.0);
        if (locSim >= 0.5) {
            matchedBadges.add("Matching location (" + found.getLocation() + ")");
        }

        // 4. Color Match (10%)
        if (isEqualIgnoreCase(lost.getColor(), found.getColor())) {
            totalScore += 10.0;
            matchedBadges.add("Same color (" + lost.getColor() + ")");
        } else if (lost.getColor() != null && found.getColor() != null &&
                  (lost.getColor().toLowerCase().contains(found.getColor().toLowerCase()) ||
                   found.getColor().toLowerCase().contains(lost.getColor().toLowerCase()))) {
            totalScore += 6.0;
            matchedBadges.add("Partial color match");
        }

        // 5. Brand Match (10%)
        if (!isGenericBrand(lost.getBrand()) && !isGenericBrand(found.getBrand()) &&
            isEqualIgnoreCase(lost.getBrand(), found.getBrand())) {
            totalScore += 10.0;
            matchedBadges.add("Same brand (" + lost.getBrand() + ")");
        } else if (isEqualIgnoreCase(lost.getBrand(), found.getBrand())) {
            totalScore += 5.0;
        }

        // 6. Date Proximity (10%)
        double dateScore = calculateDateProximityScore(lost.getItemDate(), found.getItemDate());
        totalScore += (dateScore * 10.0);
        if (dateScore >= 0.7) {
            matchedBadges.add("Close incident date (" + lost.getItemDate() + " & " + found.getItemDate() + ")");
        }

        // 7. Description Keyword Similarity (10%)
        double descSim = calculateDescriptionSimilarity(lost.getDescription(), found.getDescription());
        totalScore += (descSim * 10.0);
        if (descSim >= 0.4) {
            matchedBadges.add("Corroborating descriptions");
        }

        // Round score to 2 decimal places
        double roundedScore = Math.round(Math.min(totalScore, 100.0) * 10.0) / 10.0;
        match.setMatchScore(roundedScore);
        match.setMatchedFields(matchedBadges);
        match.setMatchStatus("PENDING");
        match.evaluateCategory();

        return match;
    }

    /**
     * Computes Jaccard/N-Gram similarity between two text strings.
     */
    public double calculateTextSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) return 0.0;
        String str1 = s1.trim().toLowerCase();
        String str2 = s2.trim().toLowerCase();

        if (str1.equals(str2)) return 1.0;
        if (str1.contains(str2) || str2.contains(str1)) return 0.85;

        // Token-based Jaccard similarity
        Set<String> set1 = new HashSet<>(Arrays.asList(str1.split("\\s+")));
        Set<String> set2 = new HashSet<>(Arrays.asList(str2.split("\\s+")));

        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        if (union.isEmpty()) return 0.0;
        double jaccard = (double) intersection.size() / union.size();

        // Bonus for common substrings
        return Math.min(1.0, jaccard * 1.2);
    }

    /**
     * Date proximity scoring:
     * - Same day: 100% (1.0)
     * - Within 1-2 days: 90% (0.9)
     * - Within 3-7 days: 70% (0.7)
     * - Within 8-14 days: 40% (0.4)
     * - Within 15-30 days: 20% (0.2)
     * - > 30 days: 0%
     */
    public double calculateDateProximityScore(Date d1, Date d2) {
        if (d1 == null || d2 == null) return 0.5; // neutral if date missing

        long daysBetween = Math.abs(ChronoUnit.DAYS.between(d1.toLocalDate(), d2.toLocalDate()));

        if (daysBetween == 0) return 1.0;
        if (daysBetween <= 2) return 0.9;
        if (daysBetween <= 7) return 0.7;
        if (daysBetween <= 14) return 0.4;
        if (daysBetween <= 30) return 0.2;
        return 0.0;
    }

    /**
     * Tokenizes descriptions, filters common stop words, and evaluates semantic overlap.
     */
    public double calculateDescriptionSimilarity(String desc1, String desc2) {
        if (desc1 == null || desc2 == null) return 0.0;

        Set<String> stopWords = new HashSet<>(Arrays.asList(
            "the", "is", "at", "which", "on", "a", "an", "and", "or", "in", "near", "with", "has", "of", "to", "for", "by"
        ));

        Set<String> words1 = new HashSet<>();
        for (String w : desc1.toLowerCase().replaceAll("[^a-z0-9 ]", "").split("\\s+")) {
            if (w.length() > 2 && !stopWords.contains(w)) words1.add(w);
        }

        Set<String> words2 = new HashSet<>();
        for (String w : desc2.toLowerCase().replaceAll("[^a-z0-9 ]", "").split("\\s+")) {
            if (w.length() > 2 && !stopWords.contains(w)) words2.add(w);
        }

        if (words1.isEmpty() || words2.isEmpty()) return 0.1;

        Set<String> common = new HashSet<>(words1);
        common.retainAll(words2);

        double overlap = (double) common.size() / Math.max(words1.size(), words2.size());
        return Math.min(1.0, overlap * 2.0); // Boost keyword overlap
    }

    private boolean isEqualIgnoreCase(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    private boolean isGenericBrand(String brand) {
        if (brand == null) return true;
        String b = brand.trim().toLowerCase();
        return b.isEmpty() || b.equals("unknown") || b.equals("generic") || b.equals("n/a") || b.equals("other");
    }
}
