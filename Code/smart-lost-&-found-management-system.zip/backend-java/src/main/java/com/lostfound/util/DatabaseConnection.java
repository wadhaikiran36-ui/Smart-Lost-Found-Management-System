package com.lostfound.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Singleton Database Connection Utility for JDBC operations.
 * Demonstrates thread-safe connection provisioning and graceful resource management.
 */
public class DatabaseConnection {

    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/lost_found_system?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASS = "root";

    private static String jdbcUrl = DEFAULT_URL;
    private static String jdbcUser = DEFAULT_USER;
    private static String jdbcPassword = DEFAULT_PASS;

    static {
        try {
            // Load MySQL Connector/J 8.x driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("CRITICAL: MySQL JDBC Driver not found in classpath. Ensure mysql-connector-java is in WEB-INF/lib.");
            e.printStackTrace();
        }
    }

    private DatabaseConnection() {
        // Private constructor to enforce Singleton pattern
    }

    /**
     * Override connection credentials dynamically (e.g., from web.xml context-param or environment)
     */
    public static void configure(String url, String username, String password) {
        if (url != null && !url.trim().isEmpty()) jdbcUrl = url;
        if (username != null && !username.trim().isEmpty()) jdbcUser = username;
        if (password != null) jdbcPassword = password;
    }

    /**
     * Obtains a new active JDBC Connection.
     * @return Connection object
     * @throws SQLException on database connectivity failure
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
    }

    /**
     * Safely closes open JDBC resources to prevent connection pool starvation and leaks.
     */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try { rs.close(); } catch (SQLException ignored) {}
        }
        if (stmt != null) {
            try { stmt.close(); } catch (SQLException ignored) {}
        }
        if (conn != null) {
            try { conn.close(); } catch (SQLException ignored) {}
        }
    }

    public static void close(Connection conn, Statement stmt) {
        close(conn, stmt, null);
    }
}
