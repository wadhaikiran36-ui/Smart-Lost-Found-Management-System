import { Item, MatchResult } from '../types';

/**
 * Client-side mirror of the Java MatchingService.java
 * Runs the exact same 7 weighted criteria algorithm for instant UI response and verification.
 */
export function calculateMatchScore(lost: Item, found: Item): MatchResult {
  let categoryScore = 0;
  let nameScore = 0;
  let locationScore = 0;
  let colorScore = 0;
  let brandScore = 0;
  let dateScore = 0;
  let descriptionScore = 0;

  const matchedFields: string[] = [];

  // 1. Category Match (20%)
  if (lost.category && found.category && lost.category.trim().toLowerCase() === found.category.trim().toLowerCase()) {
    categoryScore = 20;
    matchedFields.push(`Same category (${lost.category})`);
  }

  // 2. Item Name Similarity (20%)
  const nameSim = computeTextSimilarity(lost.itemName, found.itemName);
  nameScore = Math.round(nameSim * 20 * 10) / 10;
  if (nameSim >= 0.6) {
    matchedFields.push(`Similar item name (${Math.round(nameSim * 100)}%)`);
  }

  // 3. Location Similarity (20%)
  const locSim = computeTextSimilarity(lost.location, found.location);
  locationScore = Math.round(locSim * 20 * 10) / 10;
  if (locSim >= 0.5) {
    matchedFields.push(`Matching location (${found.location})`);
  }

  // 4. Color Match (10%)
  if (lost.color && found.color && lost.color.trim().toLowerCase() === found.color.trim().toLowerCase()) {
    colorScore = 10;
    matchedFields.push(`Same color (${lost.color})`);
  } else if (
    lost.color &&
    found.color &&
    (lost.color.toLowerCase().includes(found.color.toLowerCase()) ||
      found.color.toLowerCase().includes(lost.color.toLowerCase()))
  ) {
    colorScore = 6;
    matchedFields.push(`Partial color match`);
  }

  // 5. Brand Match (10%)
  const isGeneric = (b?: string) => !b || ['unknown', 'generic', 'n/a', 'other'].includes(b.toLowerCase().trim());
  if (!isGeneric(lost.brand) && !isGeneric(found.brand) && lost.brand.trim().toLowerCase() === found.brand.trim().toLowerCase()) {
    brandScore = 10;
    matchedFields.push(`Same brand (${lost.brand})`);
  } else if (lost.brand && found.brand && lost.brand.trim().toLowerCase() === found.brand.trim().toLowerCase()) {
    brandScore = 5;
  }

  // 6. Date Proximity (10%)
  const dateProximityRatio = computeDateProximity(lost.itemDate, found.itemDate);
  dateScore = Math.round(dateProximityRatio * 10 * 10) / 10;
  if (dateProximityRatio >= 0.7) {
    matchedFields.push(`Close incident date (${lost.itemDate} & ${found.itemDate})`);
  }

  // 7. Description Similarity (10%)
  const descSim = computeDescriptionSimilarity(lost.description, found.description);
  descriptionScore = Math.round(descSim * 10 * 10) / 10;
  if (descSim >= 0.4) {
    matchedFields.push(`Corroborating descriptions`);
  }

  const rawTotal = categoryScore + nameScore + locationScore + colorScore + brandScore + dateScore + descriptionScore;
  const matchScore = Math.min(100, Math.round(rawTotal * 10) / 10);

  let matchCategory: MatchResult['matchCategory'] = 'Unlikely Match';
  if (matchScore >= 80) matchCategory = 'High Match';
  else if (matchScore >= 60) matchCategory = 'Medium Match';
  else if (matchScore >= 40) matchCategory = 'Low Match';

  return {
    matchId: Date.now() + Math.floor(Math.random() * 1000),
    lostItemId: lost.itemId,
    foundItemId: found.itemId,
    matchScore,
    matchStatus: 'PENDING',
    createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
    lostItem: lost,
    foundItem: found,
    matchedFields,
    matchCategory,
    scoreBreakdown: {
      category: categoryScore,
      name: nameScore,
      location: locationScore,
      color: colorScore,
      brand: brandScore,
      date: dateScore,
      description: descriptionScore,
    }
  };
}

function computeTextSimilarity(s1?: string, s2?: string): number {
  if (!s1 || !s2) return 0;
  const str1 = s1.trim().toLowerCase();
  const str2 = s2.trim().toLowerCase();

  if (str1 === str2) return 1.0;
  if (str1.includes(str2) || str2.includes(str1)) return 0.85;

  const words1 = new Set(str1.split(/\s+/));
  const words2 = new Set(str2.split(/\s+/));

  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);

  if (union.size === 0) return 0;
  const jaccard = intersection.size / union.size;
  return Math.min(1.0, jaccard * 1.25);
}

function computeDateProximity(d1?: string, d2?: string): number {
  if (!d1 || !d2) return 0.5;
  try {
    const time1 = new Date(d1).getTime();
    const time2 = new Date(d2).getTime();
    const diffDays = Math.abs(time1 - time2) / (1000 * 60 * 60 * 24);

    if (diffDays === 0) return 1.0;
    if (diffDays <= 2) return 0.9;
    if (diffDays <= 7) return 0.7;
    if (diffDays <= 14) return 0.4;
    if (diffDays <= 30) return 0.2;
    return 0.0;
  } catch {
    return 0.5;
  }
}

function computeDescriptionSimilarity(d1?: string, d2?: string): number {
  if (!d1 || !d2) return 0;
  const stopWords = new Set(['the', 'is', 'at', 'which', 'on', 'a', 'an', 'and', 'or', 'in', 'near', 'with', 'has', 'of', 'to', 'for', 'by', 'during', 'floor']);

  const tokenize = (text: string) => {
    return new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9 ]/g, '')
        .split(/\s+/)
        .filter(w => w.length > 2 && !stopWords.has(w))
    );
  };

  const set1 = tokenize(d1);
  const set2 = tokenize(d2);

  if (set1.size === 0 || set2.size === 0) return 0.1;

  const common = new Set([...set1].filter(x => set2.has(x)));
  const overlap = common.size / Math.max(set1.size, set2.size);
  return Math.min(1.0, overlap * 2.0);
}
