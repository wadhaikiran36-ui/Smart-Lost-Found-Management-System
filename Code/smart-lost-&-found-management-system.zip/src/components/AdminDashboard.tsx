import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Package, 
  FileCheck, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Search, 
  Sparkles, 
  TrendingUp, 
  Trash2,
  RefreshCw
} from 'lucide-react';
import { User, Item, Claim, MatchResult } from '../types';

interface AdminDashboardProps {
  users: User[];
  items: Item[];
  claims: Claim[];
  matches: MatchResult[];
  onUpdateClaimStatus: (claimId: number, status: 'APPROVED' | 'REJECTED') => void;
  onUpdateItemStatus: (itemId: number, status: Item['status']) => void;
  onDeleteItem: (itemId: number) => void;
  onDeleteUser: (userId: number) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  users,
  items,
  claims,
  matches,
  onUpdateClaimStatus,
  onUpdateItemStatus,
  onDeleteItem,
  onDeleteUser,
}) => {
  const [adminTab, setAdminTab] = useState<'CLAIMS' | 'ITEMS' | 'USERS'>('CLAIMS');
  const [searchFilter, setSearchFilter] = useState('');

  const lostCount = items.filter((i) => i.itemType === 'LOST').length;
  const foundCount = items.filter((i) => i.itemType === 'FOUND').length;
  const pendingClaims = claims.filter((c) => c.status === 'PENDING').length;
  const successfulReturns = items.filter((i) => i.status === 'RETURNED' || i.status === 'CLAIMED').length;

  return (
    <div className="space-y-8 pb-16">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 border border-slate-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-500/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Campus Security & Administration Console</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Administrative Control Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Authorize item ownership transfers, moderate reported listings, evaluate smart match accuracy, and manage university accounts.
            </p>
          </div>
        </div>

        {/* 6 Required Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 border-t border-slate-800">
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-blue-400">{users.length}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Total Users</div>
          </div>
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-rose-400">{lostCount}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Lost Items</div>
          </div>
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-emerald-400">{foundCount}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Found Items</div>
          </div>
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-amber-400">{pendingClaims}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Pending Claims</div>
          </div>
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-teal-400">{successfulReturns}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Successful Returns</div>
          </div>
          <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-800">
            <div className="text-xl font-bold text-indigo-400">{matches.length}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Possible Matches</div>
          </div>
        </div>
      </div>

      {/* Admin Subtabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setAdminTab('CLAIMS')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            adminTab === 'CLAIMS'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Manage Claims ({claims.length})
        </button>
        <button
          onClick={() => setAdminTab('ITEMS')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            adminTab === 'ITEMS'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Moderate Items ({items.length})
        </button>
        <button
          onClick={() => setAdminTab('USERS')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            adminTab === 'USERS'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Campus Users Directory ({users.length})
        </button>
      </div>

      {/* Tab 1: Claims Adjudication */}
      {adminTab === 'CLAIMS' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Claim Verification Queue</h2>
              <p className="text-xs text-slate-500">Examine claimant proof and authorize item release</p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {claims.map((c) => (
              <div key={c.claimId} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {c.itemName || `Item #${c.itemId}`}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.status === 'PENDING'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400'
                          : c.status === 'APPROVED'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-400'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    <strong>Claimant Statement:</strong> &ldquo;{c.message}&rdquo;
                  </p>
                  <div className="text-[11px] text-slate-400">
                    By {c.claimantName} ({c.claimantStudentId || c.claimantEmail}) on {c.createdAt}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {c.status === 'PENDING' ? (
                    <>
                      <button
                        onClick={() => onUpdateClaimStatus(c.claimId, 'APPROVED')}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xs transition-colors"
                      >
                        Approve & Release
                      </button>
                      <button
                        onClick={() => onUpdateClaimStatus(c.claimId, 'REJECTED')}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-2xs transition-colors"
                      >
                        Reject Claim
                      </button>
                    </>
                  ) : (
                    <span className="text-xs text-slate-400 italic">Adjudicated</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Moderate Items */}
      {adminTab === 'ITEMS' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3.5">ID</th>
                  <th className="p-3.5">Type</th>
                  <th className="p-3.5">Item Name</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Location</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {items.map((item) => (
                  <tr key={item.itemId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 text-slate-400">#{item.itemId}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.itemType === 'LOST'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                        }`}
                      >
                        {item.itemType}
                      </span>
                    </td>
                    <td className="p-3.5 font-semibold text-slate-900 dark:text-white max-w-[180px] truncate">
                      {item.itemName}
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.category}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.location}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.itemDate}</td>
                    <td className="p-3.5">
                      <select
                        value={item.status}
                        onChange={(e) => onUpdateItemStatus(item.itemId, e.target.value as any)}
                        className="px-2 py-1 text-[11px] bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                      >
                        <option value="APPROVED">APPROVED</option>
                        <option value="CLAIMED">CLAIMED</option>
                        <option value="RETURNED">RETURNED</option>
                        <option value="REJECTED">REJECTED</option>
                      </select>
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => onDeleteItem(item.itemId)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                        title="Delete Item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Users Directory */}
      {adminTab === 'USERS' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3.5">User ID</th>
                  <th className="p-3.5">Name</th>
                  <th className="p-3.5">Student ID</th>
                  <th className="p-3.5">Campus Email</th>
                  <th className="p-3.5">Phone</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => (
                  <tr key={u.userId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 text-slate-400">#{u.userId}</td>
                    <td className="p-3.5 font-semibold text-slate-900 dark:text-white">{u.name}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{u.studentId || '—'}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{u.email}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{u.phone}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          u.role === 'ADMIN'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400'
                            : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {u.role !== 'ADMIN' && (
                        <button
                          onClick={() => onDeleteUser(u.userId)}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Remove User"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
