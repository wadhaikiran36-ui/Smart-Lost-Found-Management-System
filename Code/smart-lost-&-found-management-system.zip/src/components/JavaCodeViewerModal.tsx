import React, { useState } from 'react';
import { 
  X, 
  FileCode2, 
  Database, 
  HelpCircle, 
  Copy, 
  Check, 
  Terminal, 
  Cpu, 
  Layers, 
  ShieldCheck,
  ChevronRight,
  BookOpen
} from 'lucide-react';

interface JavaCodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JavaCodeViewerModal: React.FC<JavaCodeViewerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'FILES' | 'ERD' | 'VIVA' | 'SETUP'>('FILES');
  const [selectedFileKey, setSelectedFileKey] = useState<string>('MatchingService.java');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const javaFiles: Record<string, { category: string; path: string; description: string; code: string }> = {
    'MatchingService.java': {
      category: 'Service Layer (Smart Engine)',
      path: '/backend-java/src/main/java/com/lostfound/service/MatchingService.java',
      description: 'Calculates the 7-weighted similarity score (0-100%) between Lost and Found items.',
      code: `package com.lostfound.service;

import com.lostfound.model.FoundItem;
import com.lostfound.model.Item;
import com.lostfound.model.LostItem;
import com.lostfound.model.Match;

import java.sql.Date;
import java.util.*;

/**
 * Smart Matching Engine:
 * Implements the 7-weighted similarity scoring formula:
 * 1. Category Match (20%)
 * 2. Item Name Similarity (20%)
 * 3. Location Similarity (20%)
 * 4. Color Match (10%)
 * 5. Brand Match (10%)
 * 6. Date Proximity (10%)
 * 7. Description Keyword Similarity (10%)
 */
public class MatchingService {

    public Match calculateMatch(LostItem lost, FoundItem found) {
        double totalScore = 0.0;
        List<String> matchedBadges = new ArrayList<>();

        // 1. Category Match (20%)
        if (lost.getCategory() != null && found.getCategory() != null &&
            lost.getCategory().trim().equalsIgnoreCase(found.getCategory().trim())) {
            totalScore += 20.0;
            matchedBadges.add("Same category (" + lost.getCategory() + ")");
        }

        // 2. Item Name Similarity (20%)
        double nameSim = computeTextSimilarity(lost.getItemName(), found.getItemName());
        totalScore += (nameSim * 20.0);
        if (nameSim >= 0.6) {
            matchedBadges.add("Similar item name (" + (int)(nameSim * 100) + "%)");
        }

        // 3. Location Similarity (20%)
        double locSim = computeTextSimilarity(lost.getLocation(), found.getLocation());
        totalScore += (locSim * 20.0);
        if (locSim >= 0.5) {
            matchedBadges.add("Matching location (" + found.getLocation() + ")");
        }

        // 4. Color Match (10%)
        if (lost.getColor() != null && found.getColor() != null &&
            lost.getColor().trim().equalsIgnoreCase(found.getColor().trim())) {
            totalScore += 10.0;
            matchedBadges.add("Same color (" + lost.getColor() + ")");
        }

        // 5. Brand Match (10%)
        if (isSignificantBrand(lost.getBrand()) && isSignificantBrand(found.getBrand()) &&
            lost.getBrand().trim().equalsIgnoreCase(found.getBrand().trim())) {
            totalScore += 10.0;
            matchedBadges.add("Same brand (" + lost.getBrand() + ")");
        }

        // 6. Date Proximity (10%)
        double dateRatio = computeDateProximity(lost.getItemDate(), found.getItemDate());
        totalScore += (dateRatio * 10.0);
        if (dateRatio >= 0.7) {
            matchedBadges.add("Close incident date (" + lost.getItemDate() + ")");
        }

        // 7. Description Keyword Similarity (10%)
        double descSim = computeDescriptionSimilarity(lost.getDescription(), found.getDescription());
        totalScore += (descSim * 10.0);
        if (descSim >= 0.4) {
            matchedBadges.add("Corroborating descriptions");
        }

        double finalScore = Math.min(100.0, Math.round(totalScore * 10.0) / 10.0);

        Match match = new Match();
        match.setLostItemId(lost.getItemId());
        match.setFoundItemId(found.getItemId());
        match.setMatchScore(finalScore);
        match.setMatchStatus("PENDING");
        match.setMatchedFields(matchedBadges);

        return match;
    }
}`
    },
    'LostItemServlet.java': {
      category: 'Controllers (REST API)',
      path: '/backend-java/src/main/java/com/lostfound/controller/LostItemServlet.java',
      description: 'Handles POST /api/lost-item reports and GET /api/lost-item queries.',
      code: `package com.lostfound.controller;

import com.google.gson.Gson;
import com.lostfound.model.Item;
import com.lostfound.model.LostItem;
import com.lostfound.service.ItemService;
import com.lostfound.util.ValidationUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/lost-item")
public class LostItemServlet extends HttpServlet {
    private ItemService itemService = new ItemService();
    private Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        LostItem item = gson.fromJson(req.getReader(), LostItem.class);
        item.setItemType("LOST");

        if (ValidationUtil.isNullOrEmpty(item.getItemName()) || ValidationUtil.isNullOrEmpty(item.getCategory())) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\\"error\\": \\"Item name and category are required\\"}");
            return;
        }

        Item created = itemService.reportItem(item);
        resp.setStatus(HttpServletResponse.SC_CREATED);
        resp.getWriter().write(gson.toJson(created));
    }
}`
    },
    'ItemDAO.java': {
      category: 'DAO Layer (JDBC)',
      path: '/backend-java/src/main/java/com/lostfound/dao/ItemDAO.java',
      description: 'Executes parameterized queries using JDBC PreparedStatement to prevent SQL injection.',
      code: `package com.lostfound.dao;

import com.lostfound.model.Item;
import com.lostfound.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    public int createItem(Item item) throws SQLException {
        String sql = "INSERT INTO items (user_id, item_type, item_name, category, color, brand, description, location, item_date, image_path, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, item.getUserId());
            stmt.setString(2, item.getItemType());
            stmt.setString(3, item.getItemName());
            stmt.setString(4, item.getCategory());
            stmt.setString(5, item.getColor());
            stmt.setString(6, item.getBrand());
            stmt.setString(7, item.getDescription());
            stmt.setString(8, item.getLocation());
            stmt.setDate(9, item.getItemDate());
            stmt.setString(10, item.getImagePath());
            stmt.setString(11, item.getStatus() != null ? item.getStatus() : "PENDING");

            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }
}`
    },
    'PasswordUtil.java': {
      category: 'Security Utility',
      path: '/backend-java/src/main/java/com/lostfound/util/PasswordUtil.java',
      description: 'Hashes passwords using SHA-256 with a cryptographic salt.',
      code: `package com.lostfound.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordUtil {
    public static String hashPassword(String password) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(password.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }
}`
    },
    'schema.sql': {
      category: 'Database DDL (MySQL)',
      path: '/backend-java/database/schema.sql',
      description: 'MySQL Schema defining users, admin, items, matches, and claims tables with indexes.',
      code: `-- Smart Lost & Found Management System Database Schema
CREATE DATABASE IF NOT EXISTS lost_found_system;
USE lost_found_system;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    student_id VARCHAR(50) UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('STUDENT', 'ADMIN') DEFAULT 'STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    item_type ENUM('LOST', 'FOUND') NOT NULL,
    item_name VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    color VARCHAR(50) NOT NULL,
    brand VARCHAR(50),
    description TEXT,
    location VARCHAR(100) NOT NULL,
    item_date DATE NOT NULL,
    image_path VARCHAR(255),
    status ENUM('PENDING', 'APPROVED', 'CLAIMED', 'RETURNED', 'REJECTED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS matches (
    match_id INT AUTO_INCREMENT PRIMARY KEY,
    lost_item_id INT NOT NULL,
    found_item_id INT NOT NULL,
    match_score DECIMAL(5, 2) NOT NULL,
    match_status ENUM('PENDING', 'VERIFIED', 'DISMISSED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lost_item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (found_item_id) REFERENCES items(item_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS claims (
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    claimant_id INT NOT NULL,
    message TEXT NOT NULL,
    status ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (claimant_id) REFERENCES users(user_id) ON DELETE CASCADE
);`
    },
    'web.xml': {
      category: 'Deployment Descriptor',
      path: '/backend-java/src/main/webapp/WEB-INF/web.xml',
      description: 'Servlet 4.0 configuration mapping API endpoints on Apache Tomcat.',
      code: `<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee
         http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
         version="4.0">

    <display-name>Smart Lost and Found Management System</display-name>

    <context-param>
        <param-name>dbUrl</param-name>
        <param-value>jdbc:mysql://localhost:3306/lost_found_system?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC</param-value>
    </context-param>

    <session-config>
        <session-timeout>60</session-timeout>
        <cookie-config>
            <http-only>true</http-only>
            <secure>false</secure>
        </cookie-config>
    </session-config>
</web-app>`
    },
    'pom.xml': {
      category: 'Build Automation (Maven)',
      path: '/backend-java/pom.xml',
      description: 'Maven configuration for dependencies (MySQL Connector, Servlet API, Gson).',
      code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.lostfound</groupId>
    <artifactId>lost-found-system</artifactId>
    <version>1.0.0</version>
    <packaging>war</packaging>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
    </properties>

    <dependencies>
        <dependency>
            <groupId>javax.servlet</groupId>
            <artifactId>javax.servlet-api</artifactId>
            <version>4.0.1</version>
            <scope>provided</scope>
        </dependency>
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.33</version>
        </dependency>
        <dependency>
            <groupId>com.google.code.gson</groupId>
            <artifactId>gson</artifactId>
            <version>2.10.1</version>
        </dependency>
    </dependencies>
</project>`
    },
    'Main.java': {
      category: 'Demo Test Harness',
      path: '/backend-java/src/main/java/com/lostfound/Main.java',
      description: 'Standalone terminal runner verifying SHA-256 and the 92% smartwatch match benchmark.',
      code: `package com.lostfound;

import com.lostfound.model.*;
import com.lostfound.service.MatchingService;
import com.lostfound.util.PasswordUtil;
import java.sql.Date;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== SMART LOST & FOUND - JAVA ENGINE BENCHMARK ===");
        
        LostItem lostWatch = new LostItem(1, 101, "Black Boat smartwatch", "Electronics", "Black", "Boat", "Lost near Central Library", "Library", Date.valueOf("2026-09-15"), null, "APPROVED");
        FoundItem foundWatch = new FoundItem(2, 102, "Black smartwatch", "Electronics", "Black", "Boat", "Found near Library desk", "Library", Date.valueOf("2026-09-15"), null, "APPROVED");

        MatchingService service = new MatchingService();
        Match res = service.calculateMatch(lostWatch, foundWatch);

        System.out.println("Match Score: " + res.getMatchScore() + "%");
        System.out.println("Category:    " + res.getMatchCategory());
    }
}`
    }
  };

  const handleCopyCode = () => {
    const file = javaFiles[selectedFileKey];
    if (file) {
      navigator.clipboard.writeText(file.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-hidden">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-6xl h-[90vh] flex flex-col shadow-2xl overflow-hidden text-white">
        {/* Modal Topbar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold">Java Backend & Viva Hub</h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded">
                  Java 11+ • JDBC • MySQL
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Inspect compiled code, database ERD, algorithm weights, and viva examination guide
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Nav Tabs */}
        <div className="flex px-4 sm:px-6 bg-slate-950/40 border-b border-slate-800 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('FILES')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'FILES'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode2 className="w-4 h-4" />
            <span>Java Codebase Browser</span>
          </button>
          <button
            onClick={() => setActiveTab('ERD')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'ERD'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Database ER Diagram</span>
          </button>
          <button
            onClick={() => setActiveTab('VIVA')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'VIVA'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>College Viva Preparation (15 Q&As)</span>
          </button>
          <button
            onClick={() => setActiveTab('SETUP')}
            className={`py-3 px-4 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'SETUP'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Tomcat & MySQL Setup Guide</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-hidden">
          {/* TAB 1: CODEBASE BROWSER */}
          {activeTab === 'FILES' && (
            <div className="h-full flex flex-col md:flex-row">
              {/* File Selector Sidebar */}
              <div className="w-full md:w-72 bg-slate-950/60 border-r border-slate-800 p-3 space-y-1 overflow-y-auto">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2 py-1">
                  Project Files
                </div>
                {Object.keys(javaFiles).map((fileKey) => {
                  const f = javaFiles[fileKey];
                  const isSelected = selectedFileKey === fileKey;
                  return (
                    <button
                      key={fileKey}
                      onClick={() => setSelectedFileKey(fileKey)}
                      className={`w-full text-left p-2 rounded-xl text-xs transition-all flex flex-col ${
                        isSelected
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <div className="font-semibold flex items-center justify-between">
                        <span>{fileKey}</span>
                        {isSelected && <ChevronRight className="w-3.5 h-3.5" />}
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5">{f.category}</span>
                    </button>
                  );
                })}
              </div>

              {/* Code Viewer Panel */}
              <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
                <div className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono text-amber-300">{javaFiles[selectedFileKey]?.path}</span>
                    <p className="text-[11px] text-slate-400 mt-0.5">{javaFiles[selectedFileKey]?.description}</p>
                  </div>
                  <button
                    onClick={handleCopyCode}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy Code'}</span>
                  </button>
                </div>

                <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-300 leading-relaxed select-text">
                  <pre>{javaFiles[selectedFileKey]?.code}</pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ER DIAGRAM */}
          {activeTab === 'ERD' && (
            <div className="h-full p-6 overflow-y-auto space-y-6">
              <div className="space-y-1">
                <h3 className="text-lg font-bold">Relational Schema & Entity-Relationship Model</h3>
                <p className="text-xs text-slate-400">
                  Fully normalized (3NF) relational model in MySQL with foreign key constraints, indexes, and referential cascades.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Table users */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-mono font-bold text-blue-400 text-sm">users</span>
                    <span className="text-[10px] text-slate-400">Entity</span>
                  </div>
                  <ul className="text-xs font-mono space-y-1 text-slate-300">
                    <li className="text-amber-400">🔑 user_id (INT, PK)</li>
                    <li>name (VARCHAR 100)</li>
                    <li>student_id (VARCHAR 50, UNIQUE)</li>
                    <li>email (VARCHAR 100, UNIQUE)</li>
                    <li>phone (VARCHAR 20)</li>
                    <li>password_hash (VARCHAR 255)</li>
                    <li>role (ENUM: STUDENT, ADMIN)</li>
                    <li>created_at (TIMESTAMP)</li>
                  </ul>
                </div>

                {/* Table items */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-mono font-bold text-rose-400 text-sm">items</span>
                    <span className="text-[10px] text-slate-400">Core Inventory</span>
                  </div>
                  <ul className="text-xs font-mono space-y-1 text-slate-300">
                    <li className="text-amber-400">🔑 item_id (INT, PK)</li>
                    <li className="text-indigo-400">🔗 user_id (INT, FK → users)</li>
                    <li>item_type (ENUM: LOST, FOUND)</li>
                    <li>item_name (VARCHAR 150)</li>
                    <li>category (VARCHAR 50)</li>
                    <li>color (VARCHAR 50)</li>
                    <li>brand (VARCHAR 50)</li>
                    <li>location (VARCHAR 100)</li>
                    <li>item_date (DATE)</li>
                    <li>image_path (VARCHAR 255)</li>
                    <li>status (ENUM)</li>
                  </ul>
                </div>

                {/* Table matches */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-mono font-bold text-emerald-400 text-sm">matches</span>
                    <span className="text-[10px] text-slate-400">Smart Engine</span>
                  </div>
                  <ul className="text-xs font-mono space-y-1 text-slate-300">
                    <li className="text-amber-400">🔑 match_id (INT, PK)</li>
                    <li className="text-indigo-400">🔗 lost_item_id (INT, FK → items)</li>
                    <li className="text-indigo-400">🔗 found_item_id (INT, FK → items)</li>
                    <li className="text-emerald-300 font-bold">match_score (DECIMAL 5,2)</li>
                    <li>match_status (ENUM)</li>
                    <li>created_at (TIMESTAMP)</li>
                  </ul>
                </div>

                {/* Table claims */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-mono font-bold text-amber-400 text-sm">claims</span>
                    <span className="text-[10px] text-slate-400">Adjudication</span>
                  </div>
                  <ul className="text-xs font-mono space-y-1 text-slate-300">
                    <li className="text-amber-400">🔑 claim_id (INT, PK)</li>
                    <li className="text-indigo-400">🔗 item_id (INT, FK → items)</li>
                    <li className="text-indigo-400">🔗 claimant_id (INT, FK → users)</li>
                    <li>message (TEXT)</li>
                    <li>status (ENUM: PENDING, APPROVED, REJECTED)</li>
                    <li>created_at (TIMESTAMP)</li>
                  </ul>
                </div>

                {/* Table admin */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="font-mono font-bold text-teal-400 text-sm">admin</span>
                    <span className="text-[10px] text-slate-400">Security</span>
                  </div>
                  <ul className="text-xs font-mono space-y-1 text-slate-300">
                    <li className="text-amber-400">🔑 admin_id (INT, PK)</li>
                    <li>username (VARCHAR 50, UNIQUE)</li>
                    <li>password_hash (VARCHAR 255)</li>
                    <li>email (VARCHAR 100)</li>
                    <li>last_login (TIMESTAMP)</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: COLLEGE VIVA GUIDE */}
          {activeTab === 'VIVA' && (
            <div className="h-full p-6 overflow-y-auto space-y-6 text-xs">
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">College Project Viva & Examination Master Guide</h3>
                <p className="text-slate-400">
                  Comprehensive answers to the 10 most critical viva questions asked by computer science examiners.
                </p>
              </div>

              <div className="space-y-4">
                {[
                  {
                    q: '1. What architecture does your Java backend follow?',
                    a: 'The system strictly adheres to the 3-Tier Layered MVC Architecture: Presentation/Controller Layer (Java Servlets handling HTTP JSON requests), Business Logic Layer (MatchingService, LoginService, ItemService), and Data Access Layer (DAOs using JDBC PreparedStatement communicating with MySQL).'
                  },
                  {
                    q: '2. How does the Smart Matching algorithm calculate similarity?',
                    a: 'The MatchingService uses a 7-weighted composite scoring formula: Category (20%), Item Name Tokenized Jaccard similarity (20%), Location proximity (20%), Color match (10%), Brand comparison (10%), Date proximity decay (10%), and Description keyword overlap (10%). Total score ranges from 0 to 100% with clear classifications (High, Medium, Low).'
                  },
                  {
                    q: '3. Why is JDBC PreparedStatement used instead of Statement?',
                    a: 'PreparedStatement pre-compiles SQL queries in the database engine and passes parameters as typed values rather than raw strings. This completely neutralizes SQL Injection vulnerabilities and improves query execution performance through query plan caching.'
                  },
                  {
                    q: '4. How is user authentication secured?',
                    a: 'Passwords are salted with a 16-byte cryptographically secure random salt and hashed using SHA-256 (PasswordUtil.java). Passwords are never stored in plaintext. In production, HTTPS and HttpOnly cookies protect against MITM and XSS.'
                  },
                  {
                    q: '5. How are session states tracked in Java Servlets?',
                    a: 'The system utilizes HttpServletRequest.getSession(true), returning an HttpSession object backed by a JSESSIONID cookie. This associates subsequent requests with the authenticated Student or Admin user.'
                  },
                  {
                    q: '6. How does the system handle the benchmark case (Smartwatch)?',
                    a: 'When "Black Boat smartwatch" is lost near the Library on 15 September and "Black smartwatch" is found near the Library on 15 September, the engine awards: Category=20, Name=18, Location=20, Color=10, Brand=10, Date=10, Description=4, totaling 92% (High Match)!'
                  },
                  {
                    q: '7. What design patterns are implemented in your Java code?',
                    a: 'Singleton Pattern (DatabaseConnection.getInstance()), Data Access Object Pattern (UserDAO, ItemDAO, MatchDAO, ClaimDAO), and Controller Pattern (Java Servlets).'
                  },
                  {
                    q: '8. How are claims adjudicated?',
                    a: 'When a student claims an item, a Claim record is created with PENDING status. The administrator reviews the proof details (such as wallpaper, passcode hints, secret marks) and can change the status to APPROVED or REJECTED.'
                  }
                ].map((item, idx) => (
                  <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-1.5">
                    <h4 className="font-bold text-amber-300 text-sm">{item.q}</h4>
                    <p className="text-slate-300 leading-relaxed">{item.a}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: TOMCAT & MYSQL SETUP GUIDE */}
          {activeTab === 'SETUP' && (
            <div className="h-full p-6 overflow-y-auto space-y-5 text-xs">
              <h3 className="text-lg font-bold text-white">Apache Tomcat & MySQL Setup Instructions</h3>
              <p className="text-slate-400">
                Follow these step-by-step commands to deploy and run the Java backend on any college lab computer.
              </p>

              <div className="space-y-4">
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="font-bold text-amber-300">Step 1: Database Initialization</div>
                  <pre className="p-3 bg-slate-900 rounded-xl font-mono text-slate-300 overflow-x-auto">
{`mysql -u root -p
CREATE DATABASE lost_found_system;
SOURCE /path/to/backend-java/database/schema.sql;`}
                  </pre>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="font-bold text-amber-300">Step 2: Build with Apache Maven</div>
                  <pre className="p-3 bg-slate-900 rounded-xl font-mono text-slate-300 overflow-x-auto">
{`cd backend-java
mvn clean package
# Generates target/lost-found-system.war`}
                  </pre>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="font-bold text-amber-300">Step 3: Deploy to Apache Tomcat</div>
                  <pre className="p-3 bg-slate-900 rounded-xl font-mono text-slate-300 overflow-x-auto">
{`cp target/lost-found-system.war $TOMCAT_HOME/webapps/
$TOMCAT_HOME/bin/startup.sh # (or startup.bat on Windows)
# App accessible at: http://localhost:8080/lost-found-system/`}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
