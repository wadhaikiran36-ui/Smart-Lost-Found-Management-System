import React, { useState } from 'react';
import { 
  FileCheck, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Send, 
  User as UserIcon,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { Claim, Item, User } from '../types';

interface ClaimsPageProps {
  claims: Claim[];
  items: Item[];
  currentUser: User | null;
  onAddClaim: (claim: Claim) => void;
  onUpdateClaimStatus: (claimId: number, status: 'APPROVED' | 'REJECTED') => void;
  selectedItemForClaim: Item | null;
  setSelectedItemForClaim: (item: Item | null) => void;
  setCurrentTab: (tab: string) => void;
}

export const ClaimsPage: React.FC<ClaimsPageProps> = ({
  claims,
  items,
  currentUser,
  onAddClaim,
  onUpdateClaimStatus,
  selectedItemForClaim,
  setSelectedItemForClaim,
  setCurrentTab,
}) => {
  const [selectedItemId, setSelectedItemId] = useState<number>(
    selectedItemForClaim ? selectedItemForClaim.itemId : 0
  );
  const [proofMessage, setProofMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Available found items to claim
  const foundItems = items.filter((i) => i.itemType === 'FOUND');

  const handleSubmitClaim = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const targetId = selectedItemForClaim ? selectedItemForClaim.itemId : selectedItemId;
    if (!targetId) {
      setError('Please select an item you wish to claim.');
      return;
    }

    if (!proofMessage.trim() || proofMessage.trim().length < 15) {
      setError('Please provide detailed proof of ownership (at least 15 characters, e.g. wallpaper description, screen passcode hint, contents, purchase invoice date, serial number).');
      return;
    }

    const targetItem = items.find((i) => i.itemId === targetId);

    const newClaim: Claim = {
      claimId: Date.now(),
      itemId: targetId,
      claimantId: currentUser?.userId || 1,
      message: proofMessage.trim(),
      status: 'PENDING',
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      itemName: targetItem ? targetItem.itemName : 'Claimed Item',
      itemType: targetItem ? targetItem.itemType : 'FOUND',
      claimantName: currentUser?.name || 'Student Claimant',
      claimantEmail: currentUser?.email || 'student@campus.edu',
      claimantStudentId: currentUser?.studentId || 'STU202601',
    };

    onAddClaim(newClaim);
    setSuccess('Your claim has been submitted to the Admin for ownership verification!');
    setProofMessage('');
    setSelectedItemForClaim(null);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-500">
              Ownership Verification & Claims Management
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
              Item Claims Portal
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Submit proof of ownership to claim recovered found property or audit submitted student claims.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300">
              Total Claims: <strong className="font-bold">{claims.length}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Claim Submission Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
            <FileCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              File an Ownership Claim
            </h2>
            <p className="text-xs text-slate-500">
              Provide verifiable details only the true owner would know
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmitClaim} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Found Item to Claim *
            </label>
            {selectedItemForClaim ? (
              <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/50 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-indigo-900 dark:text-indigo-300">
                    {selectedItemForClaim.itemName}
                  </span>
                  <span className="text-slate-500 ml-2">
                    (Location: {selectedItemForClaim.location} • Found Date: {selectedItemForClaim.itemDate})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedItemForClaim(null)}
                  className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                >
                  Change
                </button>
              </div>
            ) : (
              <select
                id="select-claim-item"
                value={selectedItemId}
                onChange={(e) => setSelectedItemId(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500"
              >
                <option value={0}>-- Select from Found Items Inventory --</option>
                {foundItems.map((fi) => (
                  <option key={fi.itemId} value={fi.itemId}>
                    #{fi.itemId} - {fi.itemName} ({fi.category} - {fi.location} on {fi.itemDate})
                  </option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Verification Proof & Distinct Details *
            </label>
            <textarea
              id="textarea-claim-message"
              rows={3}
              value={proofMessage}
              onChange={(e) => setProofMessage(e.target.value)}
              placeholder="e.g. For smartwatch: wallpaper photo description, last 2 digits of passcode; For wallet: cards/cash inside; For calculator: stickers or writing on back..."
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <button
            id="btn-submit-claim"
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-all flex items-center gap-2 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Submit Claim to Admin</span>
          </button>
        </form>
      </div>

      {/* Claims List Table / Feed */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Active Item Claims</h2>
            <p className="text-xs text-slate-500">Review status and adjudication records</p>
          </div>

          {currentUser?.role === 'ADMIN' && (
            <span className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-amber-500/10 text-amber-500 border border-amber-500/30">
              Admin Mode Active: Approve/Reject enabled
            </span>
          )}
        </div>

        {claims.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">No claims recorded yet.</div>
        ) : (
          <div className="space-y-3">
            {claims.map((claim) => {
              const isPending = claim.status === 'PENDING';
              const isApproved = claim.status === 'APPROVED';

              return (
                <div
                  key={claim.claimId}
                  className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white text-sm">
                        {claim.itemName || `Item #${claim.itemId}`}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isPending
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400'
                            : isApproved
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-400'
                        }`}
                      >
                        {claim.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      <strong className="text-slate-700 dark:text-slate-200">Claimant Proof:</strong> &ldquo;{claim.message}&rdquo;
                    </p>

                    <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-3 pt-1">
                      <span>Submitted by: {claim.claimantName} ({claim.claimantStudentId || claim.claimantEmail})</span>
                      <span>•</span>
                      <span>Date: {claim.createdAt}</span>
                    </div>
                  </div>

                  {/* Admin controls */}
                  {currentUser?.role === 'ADMIN' && isPending && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => onUpdateClaimStatus(claim.claimId, 'APPROVED')}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-colors flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>
                      <button
                        onClick={() => onUpdateClaimStatus(claim.claimId, 'REJECTED')}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-xs transition-colors flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
