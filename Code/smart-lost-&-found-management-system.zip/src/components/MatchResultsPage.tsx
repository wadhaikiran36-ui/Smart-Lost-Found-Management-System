import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  MapPin, 
  Calendar, 
  Tag, 
  Palette, 
  FileText, 
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Cpu
} from 'lucide-react';
import { MatchResult, Item } from '../types';

interface MatchResultsPageProps {
  matches: MatchResult[];
  onSelectItemForClaim: (item: Item) => void;
  onOpenJavaModal: () => void;
}

export const MatchResultsPage: React.FC<MatchResultsPageProps> = ({
  matches,
  onSelectItemForClaim,
  onOpenJavaModal,
}) => {
  const [filterLevel, setFilterLevel] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');
  const [expandedMatchId, setExpandedMatchId] = useState<number | null>(null);

  const filteredMatches = matches.filter((m) => {
    if (filterLevel === 'HIGH') return m.matchScore >= 80;
    if (filterLevel === 'MEDIUM') return m.matchScore >= 60 && m.matchScore < 80;
    if (filterLevel === 'LOW') return m.matchScore >= 40 && m.matchScore < 60;
    return true;
  });

  const toggleExpand = (matchId: number) => {
    setExpandedMatchId(expandedMatchId === matchId ? null : matchId);
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-slate-900 border border-indigo-800/50 rounded-3xl p-6 sm:p-8 text-white shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Java MatchingService.java Output</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Smart Similarity Matches
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Intelligent comparison comparing opposite reports (LOST ↔ FOUND) using the weighted 7-criteria algorithm. Scores represent estimated similarity, facilitating rapid item reuniting.
            </p>
          </div>

          <button
            onClick={onOpenJavaModal}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 transition-all self-start sm:self-auto flex items-center gap-1.5"
          >
            <span>Algorithm Logic</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            onClick={() => setFilterLevel('ALL')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              filterLevel === 'ALL'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All Matches ({matches.length})
          </button>
          <button
            onClick={() => setFilterLevel('HIGH')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              filterLevel === 'HIGH'
                ? 'bg-emerald-500 text-white shadow-xs'
                : 'bg-slate-800 text-emerald-400 hover:bg-slate-700'
            }`}
          >
            High Match (&gt;=80%)
          </button>
          <button
            onClick={() => setFilterLevel('MEDIUM')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              filterLevel === 'MEDIUM'
                ? 'bg-blue-500 text-white shadow-xs'
                : 'bg-slate-800 text-blue-400 hover:bg-slate-700'
            }`}
          >
            Medium Match (60–79%)
          </button>
          <button
            onClick={() => setFilterLevel('LOW')}
            className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
              filterLevel === 'LOW'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-slate-800 text-amber-400 hover:bg-slate-700'
            }`}
          >
            Low Match (40–59%)
          </button>
        </div>
      </div>

      {/* Match Cards List */}
      {filteredMatches.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-200">No Matches Under Selected Filter</h3>
          <p className="text-xs text-slate-500">
            Select &quot;All Matches&quot; or report new items to trigger the backend comparison engine.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMatches.map((m) => {
            const isHigh = m.matchScore >= 80;
            const isMedium = m.matchScore >= 60 && m.matchScore < 80;
            const isExpanded = expandedMatchId === m.matchId;

            return (
              <div
                key={m.matchId}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xs hover:border-indigo-500/50 transition-all space-y-5"
              >
                {/* Card Top: Match Score & Category Banner */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div className="flex items-center gap-3">
                    {/* Score Circle / Badge */}
                    <div
                      className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center shadow-md font-black shrink-0 ${
                        isHigh
                          ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white'
                          : isMedium
                          ? 'bg-gradient-to-br from-blue-500 to-indigo-600 text-white'
                          : 'bg-gradient-to-br from-amber-500 to-orange-600 text-white'
                      }`}
                    >
                      <span className="text-base leading-none">{Math.round(m.matchScore)}%</span>
                      <span className="text-[9px] font-semibold opacity-90">MATCH</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-base font-bold text-slate-900 dark:text-white">
                          Possible Match Identified
                        </h2>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isHigh
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400'
                              : isMedium
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-400'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400'
                          }`}
                        >
                          {m.matchCategory}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Matched on: {m.createdAt} • Match ID #{m.matchId}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectItemForClaim(m.foundItem)}
                      className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors"
                    >
                      Submit Claim for Found Item
                    </button>
                    <button
                      onClick={() => toggleExpand(m.matchId)}
                      className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs"
                      title="Toggle Algorithm Details"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Side-by-Side Comparison: Item A (Lost) vs Item B (Found) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Lost Item (Item A) */}
                  <div className="bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white">
                        LOST ITEM (Item A)
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">
                        Reported by {m.lostItem.reporterName || 'Student'}
                      </span>
                    </div>

                    <div className="flex gap-3">
                      {m.lostItem.imagePath && (
                        <img
                          src={m.lostItem.imagePath}
                          alt={m.lostItem.itemName}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-xl object-cover shrink-0 border border-rose-200 dark:border-rose-800"
                        />
                      )}
                      <div className="min-w-0">
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                          {m.lostItem.itemName}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2">
                          {m.lostItem.description}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 text-slate-600 dark:text-slate-300 border-t border-rose-200/50 dark:border-rose-900/30">
                      <div>
                        <span className="text-slate-400">Category:</span> {m.lostItem.category}
                      </div>
                      <div>
                        <span className="text-slate-400">Location:</span> {m.lostItem.location}
                      </div>
                      <div>
                        <span className="text-slate-400">Color/Brand:</span> {m.lostItem.color} • {m.lostItem.brand}
                      </div>
                      <div>
                        <span className="text-slate-400">Date:</span> {m.lostItem.itemDate}
                      </div>
                    </div>
                  </div>

                  {/* Found Item (Item B) */}
                  <div className="bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white">
                        FOUND ITEM (Item B)
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">
                        Found by {m.foundItem.reporterName || 'Student/Staff'}
                      </span>
                    </div>

                    <div className="flex gap-3">
                      {m.foundItem.imagePath && (
                        <img
                          src={m.foundItem.imagePath}
                          alt={m.foundItem.itemName}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-xl object-cover shrink-0 border border-emerald-200 dark:border-emerald-800"
                        />
                      )}
                      <div className="min-w-0">
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                          {m.foundItem.itemName}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2">
                          {m.foundItem.description}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 text-slate-600 dark:text-slate-300 border-t border-emerald-200/50 dark:border-emerald-900/30">
                      <div>
                        <span className="text-slate-400">Category:</span> {m.foundItem.category}
                      </div>
                      <div>
                        <span className="text-slate-400">Location:</span> {m.foundItem.location}
                      </div>
                      <div>
                        <span className="text-slate-400">Color/Brand:</span> {m.foundItem.color} • {m.foundItem.brand}
                      </div>
                      <div>
                        <span className="text-slate-400">Date:</span> {m.foundItem.itemDate}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Prompt requirement: Display which fields matched */}
                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3.5 space-y-2 border border-slate-100 dark:border-slate-800">
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Matched Criteria Checklist (Weighted Corroboration):</span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {m.matchedFields.map((field, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-2xs"
                      >
                        <span className="text-emerald-500 font-bold">✓</span>
                        <span>{field}</span>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Collapsible 7-Criteria Score Breakdown */}
                {isExpanded && m.scoreBreakdown && (
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3 text-xs">
                    <div className="font-bold text-slate-800 dark:text-slate-200">
                      Weighted Score Composition (MatchingService.java):
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Category (20%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.category} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Name (20%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.name} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Location (20%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.location} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Color (10%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.color} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Brand (10%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.brand} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Date (10%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.date} pts</div>
                      </div>
                      <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        <div className="text-slate-400 text-[10px]">Desc (10%)</div>
                        <div className="font-bold text-slate-900 dark:text-white mt-0.5">{m.scoreBreakdown.description} pts</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
