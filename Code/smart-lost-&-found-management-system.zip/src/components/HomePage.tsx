import React from 'react';
import { 
  Search, 
  Sparkles, 
  HelpCircle, 
  ShieldCheck, 
  ArrowRight, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Cpu, 
  Layers, 
  FileCode2, 
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { Item, MatchResult } from '../types';

interface HomePageProps {
  items: Item[];
  matches: MatchResult[];
  setCurrentTab: (tab: string) => void;
  onOpenReportModal: (type: 'LOST' | 'FOUND') => void;
  onOpenJavaModal: () => void;
  onSelectItemForClaim: (item: Item) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  items,
  matches,
  setCurrentTab,
  onOpenReportModal,
  onOpenJavaModal,
  onSelectItemForClaim,
}) => {
  const lostCount = items.filter((i) => i.itemType === 'LOST').length;
  const foundCount = items.filter((i) => i.itemType === 'FOUND').length;
  const highMatchesCount = matches.filter((m) => m.matchScore >= 80).length;

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 text-white p-6 sm:p-10 lg:p-12 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold">
            <Cpu className="w-3.5 h-3.5" />
            <span>Full-Stack College Java Project with Matching Engine</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight">
            Smart Lost & Found <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-emerald-400">
              Management System
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            A web-based college campus system empowering students and staff to report, track, and recover misplaced belongings. Powered by a <strong className="text-white font-semibold">Java Servlet & JDBC MySQL backend</strong> executing a dedicated 7-weighted similarity algorithm.
          </p>

          {/* Core Action CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="hero-btn-report-lost"
              onClick={() => onOpenReportModal('LOST')}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/20 transition-all flex items-center gap-2"
            >
              <span>Report Lost Item</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              id="hero-btn-report-found"
              onClick={() => onOpenReportModal('FOUND')}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2"
            >
              <span>Report Found Item</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              id="hero-btn-search"
              onClick={() => setCurrentTab('search')}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all flex items-center gap-2"
            >
              <Search className="w-4 h-4" />
              <span>Search Database</span>
            </button>
            <button
              id="hero-btn-matches"
              onClick={() => setCurrentTab('matches')}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-700/50 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>View Smart Matches ({matches.length})</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-10 pt-8 border-t border-slate-800/80">
          <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800">
            <div className="text-2xl font-bold text-rose-400">{lostCount}</div>
            <div className="text-xs text-slate-400 mt-0.5">Active Lost Reports</div>
          </div>
          <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800">
            <div className="text-2xl font-bold text-emerald-400">{foundCount}</div>
            <div className="text-xs text-slate-400 mt-0.5">Registered Found Items</div>
          </div>
          <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800">
            <div className="text-2xl font-bold text-indigo-400">{highMatchesCount}</div>
            <div className="text-xs text-slate-400 mt-0.5">High Confidence Matches (&gt;=80%)</div>
          </div>
          <div className="bg-slate-800/40 p-3.5 rounded-xl border border-slate-800">
            <div className="text-2xl font-bold text-amber-400">92%</div>
            <div className="text-xs text-slate-400 mt-0.5">Smart Engine Benchmark</div>
          </div>
        </div>
      </section>

      {/* Featured Highlight: Benchmark Case from Project Objective */}
      <section className="bg-indigo-950/30 border border-indigo-800/40 rounded-2xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Benchmark Case Verified: Smartwatch Matching</span>
            </div>
            <h3 className="text-lg font-bold text-white">
              &ldquo;Black Boat smartwatch&rdquo; vs. &ldquo;Black smartwatch found near Library&rdquo;
            </h3>
            <p className="text-sm text-slate-300">
              The Java <code className="text-xs bg-slate-800 px-1 py-0.5 rounded text-amber-300">MatchingService.java</code> evaluated category (20%), item name (18%), location (20%), color (10%), brand (10%), date proximity (10%), and description (4%) to produce a <strong className="text-emerald-400 font-bold">92% High Match</strong>.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentTab('matches')}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow transition-all"
            >
              Inspect Match Details
            </button>
            <button
              onClick={onOpenJavaModal}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
            >
              View Java Code
            </button>
          </div>
        </div>
      </section>

      {/* Smart Matching Architecture Explanation Cards */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              How the Smart Matching System Works
            </h2>
            <p className="text-sm text-slate-500">
              Weighted scoring matrix computed automatically upon every item submission in Java
            </p>
          </div>
          <button
            onClick={onOpenJavaModal}
            className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>View MatchingService.java</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
          {[
            { label: 'Category Match', weight: '20%', desc: 'Exact taxonomy classification' },
            { label: 'Item Name Similarity', weight: '20%', desc: 'Tokenized Jaccard & substring' },
            { label: 'Location Similarity', weight: '20%', desc: 'Campus zone proximity' },
            { label: 'Color Match', weight: '10%', desc: 'Exact or dominant tone' },
            { label: 'Brand Match', weight: '10%', desc: 'OEM manufacturer comparison' },
            { label: 'Date Proximity', weight: '10%', desc: 'Decay score over time window' },
            { label: 'Description', weight: '10%', desc: 'Keyword & detail overlap' },
          ].map((c, i) => (
            <div
              key={i}
              className="bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 p-3.5 rounded-xl shadow-xs hover:border-indigo-500/50 transition-colors"
            >
              <div className="text-lg font-black text-indigo-600 dark:text-indigo-400">{c.weight}</div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 mt-1">{c.label}</div>
              <div className="text-[11px] text-slate-500 mt-1 leading-tight">{c.desc}</div>
            </div>
          ))}
        </div>

        {/* Scoring Thresholds Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 flex items-center justify-between text-xs">
            <span className="font-semibold text-emerald-800 dark:text-emerald-300">80% – 100%</span>
            <span className="px-2 py-0.5 rounded font-bold bg-emerald-500 text-white text-[10px]">High Match</span>
          </div>
          <div className="p-2.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/50 flex items-center justify-between text-xs">
            <span className="font-semibold text-blue-800 dark:text-blue-300">60% – 79%</span>
            <span className="px-2 py-0.5 rounded font-bold bg-blue-500 text-white text-[10px]">Medium Match</span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 flex items-center justify-between text-xs">
            <span className="font-semibold text-amber-800 dark:text-amber-300">40% – 59%</span>
            <span className="px-2 py-0.5 rounded font-bold bg-amber-500 text-white text-[10px]">Low Match</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-400">Below 40%</span>
            <span className="px-2 py-0.5 rounded font-bold bg-slate-500 text-white text-[10px]">Unlikely Match</span>
          </div>
        </div>
      </section>

      {/* Recent Items Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Recent Lost & Found Reports</h2>
            <p className="text-sm text-slate-500">Live listings registered on the college campus</p>
          </div>
          <button
            onClick={() => setCurrentTab('search')}
            className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <span>View All Items ({items.length})</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {items.slice(0, 4).map((item) => (
            <div
              key={item.itemId}
              className="group bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden shadow-xs hover:shadow-md hover:border-indigo-400/60 transition-all flex flex-col justify-between"
            >
              {/* Card Image */}
              <div className="relative h-40 bg-slate-100 dark:bg-slate-900 overflow-hidden">
                {item.imagePath ? (
                  <img
                    src={item.imagePath}
                    alt={item.itemName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                    No Photo Provided
                  </div>
                )}
                <div className="absolute top-2.5 left-2.5">
                  <span
                    className={`px-2.5 py-1 rounded-md text-[11px] font-bold shadow-sm ${
                      item.itemType === 'LOST'
                        ? 'bg-rose-600 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {item.itemType}
                  </span>
                </div>
                <div className="absolute top-2.5 right-2.5">
                  <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-900/80 text-white backdrop-blur">
                    {item.category}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base leading-snug line-clamp-1">
                    {item.itemName}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {item.description}
                  </p>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{item.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{item.itemDate}</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  {item.itemType === 'FOUND' ? (
                    <button
                      onClick={() => onSelectItemForClaim(item)}
                      className="w-full py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                    >
                      Claim This Item
                    </button>
                  ) : (
                    <button
                      onClick={() => setCurrentTab('matches')}
                      className="w-full py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 transition-colors"
                    >
                      Check Matches
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* College Viva & Architecture Callout */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400">
            <FileCode2 className="w-4 h-4" />
            <span>Academic Demonstration & Project Viva</span>
          </div>
          <h3 className="text-xl font-bold">College Java Architecture & Source Code Explorer</h3>
          <p className="text-sm text-slate-400 max-w-2xl">
            Inspect all 8 Servlets, DAOs with JDBC PreparedStatements, SHA-256 password hashing, database schema SQL, and viva oral test preparation questions.
          </p>
        </div>
        <button
          onClick={onOpenJavaModal}
          className="px-6 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 whitespace-nowrap transition-all font-bold"
        >
          Open Code & Viva Hub
        </button>
      </section>
    </div>
  );
};
