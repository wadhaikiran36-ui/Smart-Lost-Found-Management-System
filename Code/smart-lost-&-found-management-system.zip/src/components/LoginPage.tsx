import React, { useState } from 'react';
import { LogIn, Shield, User as UserIcon, Lock, Mail, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { User } from '../types';

interface LoginPageProps {
  onLoginSuccess: (user: User) => void;
  setCurrentTab: (tab: string) => void;
  existingUsers: User[];
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  setCurrentTab,
  existingUsers,
}) => {
  const [loginMode, setLoginMode] = useState<'STUDENT' | 'ADMIN'>('STUDENT');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!identifier.trim() || !password.trim()) {
      setError('Please provide both username/email and password.');
      return;
    }

    if (loginMode === 'ADMIN') {
      if (identifier.trim().toLowerCase() === 'admin' && password === 'password123') {
        const adminUser: User = {
          userId: 99,
          name: 'Prof. Ramesh Kulkarni (Admin)',
          email: 'admin@campus.edu',
          phone: '9822001122',
          role: 'ADMIN',
          createdAt: '2026-08-15 09:00:00',
        };
        onLoginSuccess(adminUser);
        setCurrentTab('admin');
        return;
      } else {
        setError('Invalid administrator credentials. Hint: use admin / password123');
        return;
      }
    }

    // Student Login
    const foundUser = existingUsers.find(
      (u) =>
        u.role === 'STUDENT' &&
        (u.email.toLowerCase() === identifier.trim().toLowerCase() ||
          (u.studentId && u.studentId.toLowerCase() === identifier.trim().toLowerCase()))
    );

    if (foundUser) {
      onLoginSuccess(foundUser);
      setCurrentTab('dashboard');
    } else {
      setError('Invalid Email or Student ID. Please check or register a new account.');
    }
  };

  const handleQuickLogin = (userType: 'rahul' | 'ananya' | 'admin') => {
    if (userType === 'admin') {
      const adminUser: User = {
        userId: 99,
        name: 'Prof. Ramesh Kulkarni (Admin)',
        email: 'admin@campus.edu',
        phone: '9822001122',
        role: 'ADMIN',
        createdAt: '2026-08-15 09:00:00',
      };
      onLoginSuccess(adminUser);
      setCurrentTab('admin');
      return;
    }

    const targetEmail = userType === 'rahul' ? 'rahul.sharma@campus.edu' : 'ananya.patel@campus.edu';
    const user = existingUsers.find((u) => u.email === targetEmail) || existingUsers[0];
    if (user) {
      onLoginSuccess(user);
      setCurrentTab('dashboard');
    }
  };

  return (
    <div className="max-w-md mx-auto py-8 px-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        {/* Role Toggle */}
        <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          <button
            id="tab-login-student"
            type="button"
            onClick={() => {
              setLoginMode('STUDENT');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              loginMode === 'STUDENT'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span>Student Login</span>
          </button>
          <button
            id="tab-login-admin"
            type="button"
            onClick={() => {
              setLoginMode('ADMIN');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              loginMode === 'ADMIN'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Admin Login</span>
          </button>
        </div>

        {/* Title */}
        <div className="text-center space-y-1">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            {loginMode === 'ADMIN' ? 'Administrator Portal' : 'Student Sign In'}
          </h2>
          <p className="text-xs text-slate-500">
            {loginMode === 'ADMIN'
              ? 'Adjudicate claims, verify matches, and audit system inventory'
              : 'Access your reported items, smart matches, and claim status'}
          </p>
        </div>

        {/* Error notification */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {loginMode === 'ADMIN' ? 'Admin Username *' : 'Email or Student ID *'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="login-input-identifier"
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder={loginMode === 'ADMIN' ? 'admin' : 'STU202601 or email@campus.edu'}
                className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Password *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="login-input-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <button
            id="btn-submit-login"
            type="submit"
            className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-xl shadow-md transition-all cursor-pointer"
          >
            {loginMode === 'ADMIN' ? 'Login as Admin' : 'Sign In'}
          </button>
        </form>

        {/* Quick Demo Accounts Helper */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 text-center">
            One-Click College Demo Accounts
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              id="demo-login-rahul"
              type="button"
              onClick={() => handleQuickLogin('rahul')}
              className="px-2 py-1.5 text-[11px] font-medium rounded-lg bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors"
            >
              Rahul (Lost)
            </button>
            <button
              id="demo-login-ananya"
              type="button"
              onClick={() => handleQuickLogin('ananya')}
              className="px-2 py-1.5 text-[11px] font-medium rounded-lg bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors"
            >
              Ananya (Found)
            </button>
            <button
              id="demo-login-admin"
              type="button"
              onClick={() => handleQuickLogin('admin')}
              className="px-2 py-1.5 text-[11px] font-medium rounded-lg bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/50 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800/60 transition-colors"
            >
              Admin
            </button>
          </div>
        </div>

        {/* Register link */}
        {loginMode === 'STUDENT' && (
          <div className="text-center text-xs text-slate-500 pt-1">
            Don&apos;t have an account yet?{' '}
            <button
              onClick={() => setCurrentTab('register')}
              className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
            >
              Register here
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
