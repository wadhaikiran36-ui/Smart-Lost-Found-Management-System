import React from 'react';
import { 
  Search, 
  PlusCircle, 
  HelpCircle, 
  ShieldCheck, 
  User as UserIcon, 
  LogOut, 
  Cpu, 
  Sparkles,
  Layers,
  FileCode2,
  Menu,
  X
} from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentUser: User | null;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onLogout: () => void;
  onOpenJavaModal: () => void;
  onOpenReportModal: (type: 'LOST' | 'FOUND') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currentTab,
  setCurrentTab,
  onLogout,
  onOpenJavaModal,
  onOpenReportModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'search', label: 'Search Items' },
    { id: 'matches', label: 'Smart Matches' },
    { id: 'claims', label: 'Claims' },
    ...(currentUser?.role === 'ADMIN'
      ? [{ id: 'admin', label: 'Admin Panel' }]
      : currentUser
      ? [{ id: 'dashboard', label: 'My Dashboard' }]
      : []),
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Name */}
          <div 
            id="nav-brand"
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-3 cursor-pointer select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white">Smart Lost & Found</span>
                <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
                  Java + JDBC
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Campus Item Matching & Recovery System</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`nav-link-${link.id}`}
                onClick={() => setCurrentTab(link.id)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === link.id
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Action CTAs and User Profile */}
          <div className="hidden lg:flex items-center gap-2.5">
            {/* Java Code & Architecture Viewer CTA */}
            <button
              id="btn-open-java-explorer"
              onClick={onOpenJavaModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 transition-colors"
              title="Inspect Java Servlets, Models, DAOs, Matching Engine and Viva Prep"
            >
              <FileCode2 className="w-4 h-4 text-amber-400" />
              <span>Java Backend & Viva</span>
            </button>

            {/* Quick Report Buttons */}
            <button
              id="btn-quick-report-lost"
              onClick={() => onOpenReportModal('LOST')}
              className="px-3 py-1.5 text-xs font-medium rounded-lg bg-rose-600/90 text-white hover:bg-rose-600 transition-colors"
            >
              Report Lost
            </button>
            <button
              id="btn-quick-report-found"
              onClick={() => onOpenReportModal('FOUND')}
              className="px-3 py-1.5 text-xs font-medium rounded-lg bg-emerald-600/90 text-white hover:bg-emerald-600 transition-colors"
            >
              Report Found
            </button>

            <div className="h-5 w-px bg-slate-800 mx-1" />

            {/* User Session status */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <div className="text-xs font-medium text-slate-200 leading-none">{currentUser.name}</div>
                  <div className="text-[10px] text-slate-400">
                    {currentUser.role === 'ADMIN' ? (
                      <span className="text-amber-400 font-semibold">Administrator</span>
                    ) : (
                      currentUser.studentId || 'Student'
                    )}
                  </div>
                </div>
                <button
                  id="btn-logout"
                  onClick={onLogout}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-rose-400 hover:bg-slate-700 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="btn-nav-login"
                  onClick={() => setCurrentTab('login')}
                  className="px-3 py-1.5 text-xs font-medium text-slate-200 hover:text-white transition-colors"
                >
                  Sign In
                </button>
                <button
                  id="btn-nav-register"
                  onClick={() => setCurrentTab('register')}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              id="btn-open-java-mobile"
              onClick={onOpenJavaModal}
              className="p-2 text-amber-400 bg-amber-500/10 rounded-lg border border-amber-500/30"
              title="Java Code Explorer"
            >
              <FileCode2 className="w-4 h-4" />
            </button>
            <button
              id="btn-mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-slate-900 px-4 pt-3 pb-5 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                setCurrentTab(link.id);
                setMobileMenuOpen(false);
              }}
              className={`block w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
                currentTab === link.id
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {link.label}
            </button>
          ))}

          <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onOpenReportModal('LOST');
                  setMobileMenuOpen(false);
                }}
                className="py-2 text-xs text-center font-medium rounded-lg bg-rose-600 text-white"
              >
                Report Lost
              </button>
              <button
                onClick={() => {
                  onOpenReportModal('FOUND');
                  setMobileMenuOpen(false);
                }}
                className="py-2 text-xs text-center font-medium rounded-lg bg-emerald-600 text-white"
              >
                Report Found
              </button>
            </div>

            {currentUser ? (
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">Logged in as {currentUser.name}</span>
                <button
                  onClick={() => {
                    onLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="text-xs text-rose-400 font-medium"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    setCurrentTab('login');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 text-xs text-center font-medium rounded-lg bg-slate-800 text-white"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    setCurrentTab('register');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2 text-xs text-center font-semibold rounded-lg bg-indigo-600 text-white"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
