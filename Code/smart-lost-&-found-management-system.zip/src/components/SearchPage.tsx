import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  MapPin, 
  Calendar, 
  Tag, 
  RotateCcw, 
  LayoutGrid, 
  List as ListIcon, 
  ArrowUpDown,
  FileCheck
} from 'lucide-react';
import { Item } from '../types';

interface SearchPageProps {
  items: Item[];
  onSelectItemForClaim: (item: Item) => void;
  setCurrentTab: (tab: string) => void;
}

export const SearchPage: React.FC<SearchPageProps> = ({
  items,
  onSelectItemForClaim,
  setCurrentTab,
}) => {
  const [keyword, setKeyword] = useState('');
  const [category, setCategory] = useState('ALL');
  const [location, setLocation] = useState('');
  const [color, setColor] = useState('');
  const [brand, setBrand] = useState('');
  const [itemType, setItemType] = useState<'ALL' | 'LOST' | 'FOUND'>('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState<'GRID' | 'TABLE'>('GRID');

  const categories = [
    'ALL',
    'Electronics',
    'Stationery',
    'Accessories',
    'Personal Items',
    'ID Cards & Documents',
    'Clothing & Footwear',
    'Books & Notebooks',
    'Sports Gear',
    'Other'
  ];

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Keyword
      if (keyword.trim()) {
        const kw = keyword.toLowerCase().trim();
        const matchesKw =
          item.itemName.toLowerCase().includes(kw) ||
          item.description.toLowerCase().includes(kw) ||
          item.location.toLowerCase().includes(kw) ||
          item.brand.toLowerCase().includes(kw);
        if (!matchesKw) return false;
      }
      // Category
      if (category !== 'ALL' && item.category !== category) return false;
      // Location
      if (location.trim() && !item.location.toLowerCase().includes(location.toLowerCase().trim())) return false;
      // Color
      if (color.trim() && !item.color.toLowerCase().includes(color.toLowerCase().trim())) return false;
      // Brand
      if (brand.trim() && !item.brand.toLowerCase().includes(brand.toLowerCase().trim())) return false;
      // Item Type
      if (itemType !== 'ALL' && item.itemType !== itemType) return false;
      // Status
      if (statusFilter !== 'ALL' && item.status !== statusFilter) return false;

      return true;
    });
  }, [items, keyword, category, location, color, brand, itemType, statusFilter]);

  const handleReset = () => {
    setKeyword('');
    setCategory('ALL');
    setLocation('');
    setColor('');
    setBrand('');
    setItemType('ALL');
    setStatusFilter('ALL');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Search Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Campus Inventory Search</h1>
            <p className="text-xs text-slate-500">Query and filter across all lost and found listings</p>
          </div>

          {/* View mode toggle */}
          <div className="flex items-center gap-2">
            <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                id="search-view-grid"
                onClick={() => setViewMode('GRID')}
                className={`p-1.5 rounded-lg transition-all ${
                  viewMode === 'GRID'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Grid Cards"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                id="search-view-table"
                onClick={() => setViewMode('TABLE')}
                className={`p-1.5 rounded-lg transition-all ${
                  viewMode === 'TABLE'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Table Layout"
              >
                <ListIcon className="w-4 h-4" />
              </button>
            </div>

            <button
              id="search-btn-reset"
              onClick={handleReset}
              className="p-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          </div>
        </div>

        {/* Primary Search Bar */}
        <div className="relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
          <input
            id="search-input-keyword"
            type="text"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="Search by keywords (e.g. smartwatch, casio, wallet, bottle, library)..."
            className="w-full pl-11 pr-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
          />
        </div>

        {/* Filter Controls Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
          {/* Item Type */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Type</label>
            <select
              id="filter-select-type"
              value={itemType}
              onChange={(e) => setItemType(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Types</option>
              <option value="LOST">Lost Items</option>
              <option value="FOUND">Found Items</option>
            </select>
          </div>

          {/* Category */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Category</label>
            <select
              id="filter-select-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Location */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Location</label>
            <input
              id="filter-input-location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Library"
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Color */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Color</label>
            <input
              id="filter-input-color"
              type="text"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              placeholder="e.g. Black, Silver"
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Brand */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Brand</label>
            <input
              id="filter-input-brand"
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="e.g. Boat, Casio"
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Status */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Status</label>
            <select
              id="filter-select-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="APPROVED">Approved</option>
              <option value="RETURNED">Returned</option>
              <option value="CLAIMED">Claimed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Result Counter */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <div>
          Showing <span className="font-bold text-slate-800 dark:text-slate-200">{filteredItems.length}</span> items
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
          <span>Real-time MySQL sync simulation</span>
        </div>
      </div>

      {/* Results View: Grid or Table */}
      {filteredItems.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-200 text-base">No Matching Items Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search criteria or resetting filters to view all listings.
          </p>
          <button
            onClick={handleReset}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-indigo-600 text-white"
          >
            Reset Filters
          </button>
        </div>
      ) : viewMode === 'GRID' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.itemId}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="relative h-44 bg-slate-100 dark:bg-slate-800">
                {item.imagePath ? (
                  <img
                    src={item.imagePath}
                    alt={item.itemName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                    No Photo
                  </div>
                )}
                <div className="absolute top-2 left-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold shadow-xs ${
                      item.itemType === 'LOST'
                        ? 'bg-rose-600 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {item.itemType}
                  </span>
                </div>
                <div className="absolute top-2 right-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-950/80 text-white backdrop-blur">
                    {item.category}
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1">
                    {item.itemName}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {item.description}
                  </p>
                </div>

                <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                  <div className="flex items-center justify-between">
                    <span>Location:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{item.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Color / Brand:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      {item.color} • {item.brand}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Date:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{item.itemDate}</span>
                  </div>
                </div>

                <div className="pt-2">
                  {item.itemType === 'FOUND' ? (
                    <button
                      onClick={() => onSelectItemForClaim(item)}
                      className="w-full py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                    >
                      Claim This Item
                    </button>
                  ) : (
                    <button
                      onClick={() => setCurrentTab('matches')}
                      className="w-full py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
                    >
                      View Smart Matches
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table Layout View */
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3.5">Type</th>
                  <th className="p-3.5">Item Name</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Location</th>
                  <th className="p-3.5">Color / Brand</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredItems.map((item) => (
                  <tr key={item.itemId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.itemType === 'LOST'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                        }`}
                      >
                        {item.itemType}
                      </span>
                    </td>
                    <td className="p-3.5 font-semibold text-slate-900 dark:text-white max-w-[200px] truncate">
                      {item.itemName}
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.category}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.location}</td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">
                      {item.color} {item.brand ? `(${item.brand})` : ''}
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">{item.itemDate}</td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 text-[10px] rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {item.itemType === 'FOUND' ? (
                        <button
                          onClick={() => onSelectItemForClaim(item)}
                          className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-indigo-600 text-white hover:bg-indigo-500"
                        >
                          Claim
                        </button>
                      ) : (
                        <button
                          onClick={() => setCurrentTab('matches')}
                          className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
                        >
                          Matches
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
