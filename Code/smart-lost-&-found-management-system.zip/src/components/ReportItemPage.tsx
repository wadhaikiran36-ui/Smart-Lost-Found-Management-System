import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  Upload, 
  MapPin, 
  Calendar, 
  Tag, 
  Palette, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Eye
} from 'lucide-react';
import { Item, MatchResult, User } from '../types';
import { calculateMatchScore } from '../services/matchingEngine';

interface ReportItemPageProps {
  initialType: 'LOST' | 'FOUND';
  currentUser: User | null;
  allItems: Item[];
  onSubmitItem: (item: Item) => void;
  setCurrentTab: (tab: string) => void;
}

export const ReportItemPage: React.FC<ReportItemPageProps> = ({
  initialType,
  currentUser,
  allItems,
  onSubmitItem,
  setCurrentTab,
}) => {
  const [itemType, setItemType] = useState<'LOST' | 'FOUND'>(initialType);
  const [itemName, setItemName] = useState('');
  const [category, setCategory] = useState('Electronics');
  const [color, setColor] = useState('');
  const [brand, setBrand] = useState('');
  const [location, setLocation] = useState('');
  const [itemDate, setItemDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const categories = [
    'Electronics',
    'Stationery',
    'Accessories',
    'Personal Items',
    'ID Cards & Documents',
    'Clothing & Footwear',
    'Books & Notebooks',
    'Sports Gear',
    'Other'
  ];

  // Real-time draft item for live matching prediction
  const draftItem: Item = useMemo(() => ({
    itemId: 999999,
    userId: currentUser?.userId || 1,
    itemType,
    itemName,
    category,
    color,
    brand,
    description,
    location,
    itemDate,
    status: 'APPROVED',
    createdAt: new Date().toISOString(),
  }), [itemType, itemName, category, color, brand, description, location, itemDate, currentUser]);

  // Opposite items pool for live matching prediction
  const oppositeType = itemType === 'LOST' ? 'FOUND' : 'LOST';
  const liveMatches = useMemo(() => {
    if (!itemName.trim() || itemName.length < 3) return [];
    const candidates = allItems.filter((i) => i.itemType === oppositeType);
    const results: MatchResult[] = [];

    for (const c of candidates) {
      const lost = itemType === 'LOST' ? draftItem : c;
      const found = itemType === 'FOUND' ? draftItem : c;
      const res = calculateMatchScore(lost, found);
      if (res.matchScore >= 40) {
        results.push(res);
      }
    }

    return results.sort((a, b) => b.matchScore - a.matchScore);
  }, [draftItem, allItems, oppositeType, itemName, itemType]);

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!itemName.trim()) {
      setError('Please provide the item name.');
      return;
    }
    if (!category.trim()) {
      setError('Please select a valid category.');
    }
    if (!color.trim()) {
      setError('Color specification is required.');
      return;
    }
    if (!location.trim()) {
      setError('Please indicate where the item was lost or found.');
      return;
    }
    if (!itemDate) {
      setError('Please select the incident date.');
      return;
    }
    if (!description.trim() || description.trim().length < 10) {
      setError('Please provide a descriptive explanation (at least 10 characters).');
      return;
    }

    const newItem: Item = {
      itemId: Date.now(),
      userId: currentUser?.userId || 1,
      itemType,
      itemName: itemName.trim(),
      category: category.trim(),
      color: color.trim(),
      brand: brand.trim() || 'Unknown',
      description: description.trim(),
      location: location.trim(),
      itemDate,
      imagePath: imagePreview || 'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?w=400&auto=format&fit=crop&q=60',
      status: 'APPROVED',
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      reporterName: currentUser?.name || 'Rahul Sharma',
      reporterContact: currentUser?.phone || '9876543210',
    };

    onSubmitItem(newItem);
    setSuccess(`Your ${itemType.toLowerCase()} item report was successfully registered! Computing matches...`);

    setTimeout(() => {
      setCurrentTab('matches');
    }, 1200);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-8">
      {/* Header and Type Selector */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-500">
              Campus Inventory Registration
            </span>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mt-1">
              Report {itemType === 'LOST' ? 'Lost Item' : 'Found Item'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {itemType === 'LOST'
                ? 'Submit detailed specifications of your lost item so our smart algorithm can match it against found reports.'
                : 'Help a fellow student or staff member by registering an item you discovered on campus.'}
            </p>
          </div>

          {/* Toggle Button */}
          <div className="inline-flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl self-start sm:self-auto">
            <button
              type="button"
              id="report-toggle-lost"
              onClick={() => setItemType('LOST')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                itemType === 'LOST'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-rose-500'
              }`}
            >
              Report Lost
            </button>
            <button
              type="button"
              id="report-toggle-found"
              onClick={() => setItemType('FOUND')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                itemType === 'FOUND'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-emerald-500'
              }`}
            >
              Report Found
            </button>
          </div>
        </div>

        {/* Feedback alerts */}
        {error && (
          <div className="mt-4 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mt-4 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-6 space-y-5">
          {/* Row 1: Item Name & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Item Name *
              </label>
              <input
                id="input-item-name"
                type="text"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="e.g. Black Boat smartwatch, Casio fx-991EX..."
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                id="select-item-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Color, Brand, Location, Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Primary Color *
              </label>
              <input
                id="input-item-color"
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="e.g. Black, Silver, Navy"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Brand / Manufacturer
              </label>
              <input
                id="input-item-brand"
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="e.g. Boat, Apple, Casio, Dell"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Campus Location *
              </label>
              <input
                id="input-item-location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Library, Physics Lab, Cafeteria"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Date of Incident *
              </label>
              <input
                id="input-item-date"
                type="date"
                value={itemDate}
                onChange={(e) => setItemDate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Row 3: Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Detailed Description & Distinguishing Marks *
            </label>
            <textarea
              id="textarea-item-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide identifiable markings, scratches, stickers, wallpapers, case models, or exact location details..."
              className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          {/* Row 4: Photo upload */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Item Photograph (Optional but increases match accuracy)
            </label>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <label className="cursor-pointer flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-600 dark:text-slate-300 font-medium">
                <Upload className="w-4 h-4 text-slate-400" />
                <span>Upload from Device</span>
                <input
                  id="input-item-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageFile}
                  className="hidden"
                />
              </label>

              {imagePreview && (
                <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImagePreview(null)}
                    className="absolute top-0 right-0 bg-rose-600 text-white rounded-bl p-0.5 text-[9px]"
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              id="btn-submit-item-report"
              type="submit"
              className={`w-full py-3 rounded-xl text-sm font-bold text-white shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 ${
                itemType === 'LOST'
                  ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/20'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20'
              }`}
            >
              <span>Submit {itemType === 'LOST' ? 'Lost Item Report' : 'Found Item Report'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>

      {/* Real-time Predictive Matching Banner */}
      {liveMatches.length > 0 && (
        <div className="bg-indigo-950/40 border border-indigo-800/50 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Live Smart Matching Engine Preview ({liveMatches.length} candidates detected)
              </h3>
              <p className="text-xs text-slate-400">
                Java similarity calculation based on your current draft values
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {liveMatches.slice(0, 2).map((m) => (
              <div
                key={m.matchId}
                className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3"
              >
                <div className="space-y-1 min-w-0">
                  <div className="text-xs font-semibold text-white truncate">
                    {itemType === 'LOST' ? m.foundItem.itemName : m.lostItem.itemName}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Location: {itemType === 'LOST' ? m.foundItem.location : m.lostItem.location} • Date: {itemType === 'LOST' ? m.foundItem.itemDate : m.lostItem.itemDate}
                  </div>
                  <div className="flex flex-wrap gap-1 pt-1">
                    {m.matchedFields.slice(0, 2).map((b, idx) => (
                      <span key={idx} className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-emerald-400 border border-slate-700">
                        ✓ {b}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-lg font-black text-emerald-400">{m.matchScore}%</div>
                  <div className="text-[10px] text-slate-400">{m.matchCategory}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
