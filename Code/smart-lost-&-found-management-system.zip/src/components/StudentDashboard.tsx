import React, { useState } from 'react';
import { 
  User as UserIcon, 
  Sparkles, 
  Package, 
  FileCheck, 
  LogOut, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Plus, 
  ExternalLink,
  Edit2
} from 'lucide-react';
import { User, Item, MatchResult, Claim } from '../types';

interface StudentDashboardProps {
  currentUser: User;
  items: Item[];
  matches: MatchResult[];
  claims: Claim[];
  onLogout: () => void;
  setCurrentTab: (tab: string) => void;
  onOpenReportModal: (type: 'LOST' | 'FOUND') => void;
  onMarkItemRecovered: (itemId: number) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  currentUser,
  items,
  matches,
  claims,
  onLogout,
  setCurrentTab,
  onOpenReportModal,
  onMarkItemRecovered,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'REPORTS' | 'MATCHES' | 'CLAIMS' | 'PROFILE'>('REPORTS');

  // Items reported by this student
  const myItems = items.filter((i) => i.userId === currentUser.userId);
  const myLost = myItems.filter((i) => i.itemType === 'LOST');
  const myFound = myItems.filter((i) => i.itemType === 'FOUND');

  // Matches involving this student's items
  const myItemIds = new Set(myItems.map((i) => i.itemId));
  const myMatches = matches.filter(
    (m) => myItemIds.has(m.lostItemId) || myItemIds.has(m.foundItemId)
  );

  // Claims filed by this student
  const myClaims = claims.filter((c) => c.claimantId === currentUser.userId);

  return (
    <div className="space-y-6 pb-16">
      {/* Student Welcome Profile Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center shadow-lg shadow-indigo-600/20">
              {currentUser.name.charAt(0)}
            </div>
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {currentUser.name}
                </h1>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                  {currentUser.studentId || 'Student'}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {currentUser.email} • {currentUser.phone}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenReportModal('LOST')}
              className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Report Lost</span>
            </button>
            <button
              onClick={() => onOpenReportModal('FOUND')}
              className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Report Found</span>
            </button>
            <button
              onClick={onLogout}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-rose-500 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 text-center">
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40">
            <div className="text-xl font-bold text-rose-600 dark:text-rose-400">{myLost.length}</div>
            <div className="text-[11px] text-slate-500">My Lost Reports</div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40">
            <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{myFound.length}</div>
            <div className="text-[11px] text-slate-500">My Found Reports</div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40">
            <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">{myMatches.length}</div>
            <div className="text-[11px] text-slate-500">Algorithm Matches</div>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40">
            <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{myClaims.length}</div>
            <div className="text-[11px] text-slate-500">My Claims Filed</div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveSubTab('REPORTS')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeSubTab === 'REPORTS'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          My Reported Items ({myItems.length})
        </button>
        <button
          onClick={() => setActiveSubTab('MATCHES')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeSubTab === 'MATCHES'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Possible Matches ({myMatches.length})
        </button>
        <button
          onClick={() => setActiveSubTab('CLAIMS')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeSubTab === 'CLAIMS'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          My Claims ({myClaims.length})
        </button>
        <button
          onClick={() => setActiveSubTab('PROFILE')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeSubTab === 'PROFILE'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          Account Profile
        </button>
      </div>

      {/* Tab 1: My Reported Items */}
      {activeSubTab === 'REPORTS' && (
        <div className="space-y-4">
          {myItems.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl space-y-3">
              <Package className="w-8 h-8 text-slate-400 mx-auto" />
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">No items reported yet</h3>
              <p className="text-xs text-slate-500">Misplaced an item or found someone&apos;s lost belongings?</p>
              <div className="flex justify-center gap-2 pt-2">
                <button
                  onClick={() => onOpenReportModal('LOST')}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-rose-600 text-white"
                >
                  Report Lost
                </button>
                <button
                  onClick={() => onOpenReportModal('FOUND')}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 text-white"
                >
                  Report Found
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myItems.map((item) => (
                <div
                  key={item.itemId}
                  className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.itemType === 'LOST'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                          : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400'
                      }`}
                    >
                      {item.itemType}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      Status: {item.status}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      {item.itemName}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{item.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <div>Location: <strong className="text-slate-700 dark:text-slate-300">{item.location}</strong></div>
                    <div>Date: <strong className="text-slate-700 dark:text-slate-300">{item.itemDate}</strong></div>
                    <div>Category: <strong className="text-slate-700 dark:text-slate-300">{item.category}</strong></div>
                    <div>Color: <strong className="text-slate-700 dark:text-slate-300">{item.color}</strong></div>
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    {item.status !== 'RETURNED' ? (
                      <button
                        onClick={() => onMarkItemRecovered(item.itemId)}
                        className="w-full py-1.5 text-xs font-semibold rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100"
                      >
                        ✓ Mark as Recovered / Resolved
                      </button>
                    ) : (
                      <div className="w-full text-center text-xs font-bold text-emerald-600 py-1">
                        Item Recovered & Returned
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Possible Matches for my items */}
      {activeSubTab === 'MATCHES' && (
        <div className="space-y-4">
          {myMatches.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl text-xs text-slate-500">
              No matches computed yet for your items. When an item with similar attributes is reported, it will appear here automatically.
            </div>
          ) : (
            <div className="space-y-3">
              {myMatches.map((m) => (
                <div
                  key={m.matchId}
                  className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white text-sm">
                        {m.lostItem.itemName} ↔ {m.foundItem.itemName}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400">
                        {m.matchScore}% Score
                      </span>
                    </div>
                    <div className="text-xs text-slate-500">
                      Location: {m.foundItem.location} • Category: {m.foundItem.category}
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentTab('matches')}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-500"
                  >
                    View Comparison
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: My Claims */}
      {activeSubTab === 'CLAIMS' && (
        <div className="space-y-4">
          {myClaims.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl text-xs text-slate-500">
              You haven&apos;t submitted any item claims yet.
            </div>
          ) : (
            <div className="space-y-3">
              {myClaims.map((c) => (
                <div
                  key={c.claimId}
                  className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {c.itemName || `Item #${c.itemId}`}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.status === 'PENDING'
                          ? 'bg-amber-100 text-amber-800'
                          : c.status === 'APPROVED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    <strong>Your Proof Statement:</strong> &ldquo;{c.message}&rdquo;
                  </p>
                  <div className="text-[10px] text-slate-400">Submitted on: {c.createdAt}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Account Profile */}
      {activeSubTab === 'PROFILE' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 max-w-lg">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Student Information</h2>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Full Name</span>
              <span className="font-semibold text-slate-900 dark:text-white">{currentUser.name}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Student ID</span>
              <span className="font-semibold text-slate-900 dark:text-white">{currentUser.studentId || 'N/A'}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">University Email</span>
              <span className="font-semibold text-slate-900 dark:text-white">{currentUser.email}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Phone Number</span>
              <span className="font-semibold text-slate-900 dark:text-white">{currentUser.phone}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500">Role / Access</span>
              <span className="font-semibold text-indigo-600 dark:text-indigo-400">{currentUser.role}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-500">Account Created</span>
              <span className="font-semibold text-slate-900 dark:text-white">{currentUser.createdAt}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
