export interface User {
  userId: number;
  name: string;
  email: string;
  phone: string;
  role: 'STUDENT' | 'ADMIN';
  studentId?: string;
  createdAt: string;
}

export interface Item {
  itemId: number;
  userId: number;
  itemType: 'LOST' | 'FOUND';
  itemName: string;
  category: string;
  color: string;
  brand: string;
  description: string;
  location: string;
  itemDate: string;
  imagePath?: string;
  status: 'PENDING' | 'APPROVED' | 'CLAIMED' | 'RETURNED' | 'REJECTED';
  createdAt: string;
  reporterName?: string;
  reporterContact?: string;
}

export interface MatchResult {
  matchId: number;
  lostItemId: number;
  foundItemId: number;
  matchScore: number;
  matchStatus: 'PENDING' | 'VERIFIED' | 'DISMISSED';
  createdAt: string;
  lostItem: Item;
  foundItem: Item;
  matchedFields: string[];
  matchCategory: 'High Match' | 'Medium Match' | 'Low Match' | 'Unlikely Match';
  scoreBreakdown?: {
    category: number;
    name: number;
    location: number;
    color: number;
    brand: number;
    date: number;
    description: number;
  };
}

export interface Claim {
  claimId: number;
  itemId: number;
  claimantId: number;
  message: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
  itemName?: string;
  itemType?: 'LOST' | 'FOUND';
  claimantName?: string;
  claimantEmail?: string;
  claimantStudentId?: string;
}

export interface AdminStats {
  totalUsers: number;
  lostItems: number;
  foundItems: number;
  pendingClaims: number;
  successfulReturns: number;
  possibleMatches: number;
}
