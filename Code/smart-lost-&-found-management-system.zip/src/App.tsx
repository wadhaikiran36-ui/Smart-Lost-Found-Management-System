import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { RegisterPage } from './components/RegisterPage';
import { LoginPage } from './components/LoginPage';
import { StudentDashboard } from './components/StudentDashboard';
import { ReportItemPage } from './components/ReportItemPage';
import { SearchPage } from './components/SearchPage';
import { MatchResultsPage } from './components/MatchResultsPage';
import { ClaimsPage } from './components/ClaimsPage';
import { AdminDashboard } from './components/AdminDashboard';
import { JavaCodeViewerModal } from './components/JavaCodeViewerModal';

import { User, Item, Claim, MatchResult } from './types';
import { INITIAL_USERS, INITIAL_ITEMS, INITIAL_CLAIMS } from './data/mockData';
import { calculateMatchScore } from './services/matchingEngine';

export default function App() {
  // State initialization
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [items, setItems] = useState<Item[]>(INITIAL_ITEMS);
  const [claims, setClaims] = useState<Claim[]>(INITIAL_CLAIMS);

  // Default logged in as Rahul Sharma (Student) for quick interactive testing
  const [currentUser, setCurrentUser] = useState<User | null>(INITIAL_USERS[0]);

  const [currentTab, setCurrentTab] = useState<string>('home');
  const [reportType, setReportType] = useState<'LOST' | 'FOUND'>('LOST');
  const [isJavaModalOpen, setIsJavaModalOpen] = useState<boolean>(false);
  const [selectedItemForClaim, setSelectedItemForClaim] = useState<Item | null>(null);

  // Dynamically compute Smart Matches across all lost and found items
  const matches: MatchResult[] = useMemo(() => {
    const lostList = items.filter((i) => i.itemType === 'LOST');
    const foundList = items.filter((i) => i.itemType === 'FOUND');
    const results: MatchResult[] = [];

    for (const lost of lostList) {
      for (const found of foundList) {
        const match = calculateMatchScore(lost, found);
        // Only include candidate matches with score >= 40% (or show in list)
        if (match.matchScore >= 40) {
          results.push(match);
        }
      }
    }

    // Sort highest score first
    return results.sort((a, b) => b.matchScore - a.matchScore);
  }, [items]);

  // Handlers
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentTab('home');
  };

  const handleRegister = (newUser: User) => {
    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
  };

  const handleAddItem = (newItem: Item) => {
    setItems((prev) => [newItem, ...prev]);
  };

  const handleUpdateItemStatus = (itemId: number, status: Item['status']) => {
    setItems((prev) =>
      prev.map((it) => (it.itemId === itemId ? { ...it, status } : it))
    );
  };

  const handleDeleteItem = (itemId: number) => {
    setItems((prev) => prev.filter((it) => it.itemId !== itemId));
  };

  const handleDeleteUser = (userId: number) => {
    setUsers((prev) => prev.filter((u) => u.userId !== userId));
  };

  const handleAddClaim = (newClaim: Claim) => {
    setClaims((prev) => [newClaim, ...prev]);
  };

  const handleUpdateClaimStatus = (claimId: number, status: 'APPROVED' | 'REJECTED') => {
    setClaims((prev) =>
      prev.map((c) => (c.claimId === claimId ? { ...c, status } : c))
    );

    // If approved, mark the item as CLAIMED
    if (status === 'APPROVED') {
      const claim = claims.find((c) => c.claimId === claimId);
      if (claim) {
        handleUpdateItemStatus(claim.itemId, 'CLAIMED');
      }
    }
  };

  const handleOpenReport = (type: 'LOST' | 'FOUND') => {
    setReportType(type);
    setCurrentTab(type === 'LOST' ? 'report-lost' : 'report-found');
  };

  const handleSelectItemForClaim = (item: Item) => {
    setSelectedItemForClaim(item);
    setCurrentTab('claims');
  };

  const handleMarkItemRecovered = (itemId: number) => {
    handleUpdateItemStatus(itemId, 'RETURNED');
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Navigation Bar */}
      <Navbar
        currentUser={currentUser}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onLogout={handleLogout}
        onOpenJavaModal={() => setIsJavaModalOpen(true)}
        onOpenReportModal={handleOpenReport}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'home' && (
          <HomePage
            items={items}
            matches={matches}
            setCurrentTab={setCurrentTab}
            onOpenReportModal={handleOpenReport}
            onOpenJavaModal={() => setIsJavaModalOpen(true)}
            onSelectItemForClaim={handleSelectItemForClaim}
          />
        )}

        {currentTab === 'search' && (
          <SearchPage
            items={items}
            onSelectItemForClaim={handleSelectItemForClaim}
            setCurrentTab={setCurrentTab}
          />
        )}

        {currentTab === 'matches' && (
          <MatchResultsPage
            matches={matches}
            onSelectItemForClaim={handleSelectItemForClaim}
            onOpenJavaModal={() => setIsJavaModalOpen(true)}
          />
        )}

        {currentTab === 'claims' && (
          <ClaimsPage
            claims={claims}
            items={items}
            currentUser={currentUser}
            onAddClaim={handleAddClaim}
            onUpdateClaimStatus={handleUpdateClaimStatus}
            selectedItemForClaim={selectedItemForClaim}
            setSelectedItemForClaim={setSelectedItemForClaim}
            setCurrentTab={setCurrentTab}
          />
        )}

        {currentTab === 'dashboard' && currentUser && (
          <StudentDashboard
            currentUser={currentUser}
            items={items}
            matches={matches}
            claims={claims}
            onLogout={handleLogout}
            setCurrentTab={setCurrentTab}
            onOpenReportModal={handleOpenReport}
            onMarkItemRecovered={handleMarkItemRecovered}
          />
        )}

        {currentTab === 'admin' && currentUser?.role === 'ADMIN' && (
          <AdminDashboard
            users={users}
            items={items}
            claims={claims}
            matches={matches}
            onUpdateClaimStatus={handleUpdateClaimStatus}
            onUpdateItemStatus={handleUpdateItemStatus}
            onDeleteItem={handleDeleteItem}
            onDeleteUser={handleDeleteUser}
          />
        )}

        {currentTab === 'login' && (
          <LoginPage
            onLoginSuccess={handleLoginSuccess}
            setCurrentTab={setCurrentTab}
            existingUsers={users}
          />
        )}

        {currentTab === 'register' && (
          <RegisterPage
            onRegister={handleRegister}
            setCurrentTab={setCurrentTab}
            existingUsers={users}
          />
        )}

        {(currentTab === 'report-lost' || currentTab === 'report-found') && (
          <ReportItemPage
            initialType={currentTab === 'report-lost' ? 'LOST' : 'FOUND'}
            currentUser={currentUser}
            allItems={items}
            onSubmitItem={handleAddItem}
            setCurrentTab={setCurrentTab}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-200">Smart Lost & Found Management System</span>
            <span>•</span>
            <span>College Capstone Project</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Java Servlets / JSP</span>
            <span>•</span>
            <span>JDBC (PreparedStatement)</span>
            <span>•</span>
            <span>MySQL 8.0</span>
            <span>•</span>
            <button
              onClick={() => setIsJavaModalOpen(true)}
              className="text-amber-400 hover:underline font-semibold"
            >
              Open Java Backend Code Explorer
            </button>
          </div>
        </div>
      </footer>

      {/* Java Code & Viva Modal */}
      <JavaCodeViewerModal
        isOpen={isJavaModalOpen}
        onClose={() => setIsJavaModalOpen(false)}
      />
    </div>
  );
}
