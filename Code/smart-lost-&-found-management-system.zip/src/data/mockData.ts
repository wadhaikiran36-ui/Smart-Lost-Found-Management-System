import { Item, User, Claim } from '../types';

export const INITIAL_USERS: User[] = [
  {
    userId: 1,
    name: 'Rahul Sharma',
    studentId: 'STU202601',
    email: 'rahul.sharma@campus.edu',
    phone: '9876543210',
    role: 'STUDENT',
    createdAt: '2026-09-01 10:00:00'
  },
  {
    userId: 2,
    name: 'Ananya Patel',
    studentId: 'STU202602',
    email: 'ananya.patel@campus.edu',
    phone: '9812345678',
    role: 'STUDENT',
    createdAt: '2026-09-02 11:30:00'
  },
  {
    userId: 3,
    name: 'Vikram Singh',
    studentId: 'STU202603',
    email: 'vikram.singh@campus.edu',
    phone: '9765432109',
    role: 'STUDENT',
    createdAt: '2026-09-05 14:15:00'
  },
  {
    userId: 99,
    name: 'Prof. Ramesh Kulkarni (Admin)',
    email: 'admin@campus.edu',
    phone: '9822001122',
    role: 'ADMIN',
    createdAt: '2026-08-15 09:00:00'
  }
];

export const INITIAL_ITEMS: Item[] = [
  // User Prompt lost smartwatch example:
  {
    itemId: 1,
    userId: 1,
    itemType: 'LOST',
    itemName: 'Black Boat smartwatch',
    category: 'Electronics',
    color: 'Black',
    brand: 'Boat',
    description: 'Lost near Central Library reading hall 2nd floor during afternoon study session. Square dial with silicone strap.',
    location: 'Library',
    itemDate: '2026-09-15',
    imagePath: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-15 14:10:00',
    reporterName: 'Rahul Sharma',
    reporterContact: '9876543210'
  },
  {
    itemId: 2,
    userId: 2,
    itemType: 'LOST',
    itemName: 'Scientific Calculator fx-991EX',
    category: 'Stationery',
    color: 'Black',
    brand: 'Casio',
    description: 'Left on bench outside Physics lab room 304. Has blue anime sticker on the back casing.',
    location: 'Physics Lab',
    itemDate: '2026-09-14',
    imagePath: 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-14 16:20:00',
    reporterName: 'Ananya Patel',
    reporterContact: '9812345678'
  },
  {
    itemId: 3,
    userId: 3,
    itemType: 'LOST',
    itemName: 'Leather Bi-fold Wallet',
    category: 'Accessories',
    color: 'Brown',
    brand: 'WildHorn',
    description: 'Contains college student ID STU202603 and Metro transit smart card. Lost near Cafeteria billing counter.',
    location: 'Cafeteria',
    itemDate: '2026-09-13',
    imagePath: 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-13 13:00:00',
    reporterName: 'Vikram Singh',
    reporterContact: '9765432109'
  },
  {
    itemId: 4,
    userId: 1,
    itemType: 'LOST',
    itemName: 'Steel Water Flask 750ml',
    category: 'Personal Items',
    color: 'Silver',
    brand: 'Milton',
    description: 'Thermo steel flask with slight dent on bottom rim. Left in Main Auditorium row G.',
    location: 'Auditorium',
    itemDate: '2026-09-12',
    imagePath: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-12 18:30:00',
    reporterName: 'Rahul Sharma',
    reporterContact: '9876543210'
  },
  // Found items
  {
    itemId: 5,
    userId: 2,
    itemType: 'FOUND',
    itemName: 'Black smartwatch',
    category: 'Electronics',
    color: 'Black',
    brand: 'Boat',
    description: 'Found resting on a wooden chair near the Central Library entrance desk. Display works, black band.',
    location: 'Library',
    itemDate: '2026-09-15',
    imagePath: 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-15 15:45:00',
    reporterName: 'Ananya Patel',
    reporterContact: '9812345678'
  },
  {
    itemId: 6,
    userId: 1,
    itemType: 'FOUND',
    itemName: 'Casio Calculator',
    category: 'Stationery',
    color: 'Black',
    brand: 'Casio',
    description: 'Found under desk in Science block 3rd floor corridor right next to Physics Lab door.',
    location: 'Physics Lab',
    itemDate: '2026-09-14',
    imagePath: 'https://images.unsplash.com/photo-1611125832047-1d7ad1e8e48f?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-14 17:00:00',
    reporterName: 'Rahul Sharma',
    reporterContact: '9876543210'
  },
  {
    itemId: 7,
    userId: 3,
    itemType: 'FOUND',
    itemName: 'Noise Wireless Earbuds Case',
    category: 'Electronics',
    color: 'White',
    brand: 'Noise',
    description: 'Found on badminton court bench at indoor sports complex. Case with both earbuds inside.',
    location: 'Sports Complex',
    itemDate: '2026-09-11',
    imagePath: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-11 19:10:00',
    reporterName: 'Vikram Singh',
    reporterContact: '9765432109'
  },
  {
    itemId: 8,
    userId: 2,
    itemType: 'FOUND',
    itemName: 'Brown Leather Card Holder',
    category: 'Accessories',
    color: 'Brown',
    brand: 'Generic',
    description: 'Found near dining area counter in student cafeteria. Has cards inside.',
    location: 'Cafeteria',
    itemDate: '2026-09-13',
    imagePath: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&auto=format&fit=crop&q=60',
    status: 'APPROVED',
    createdAt: '2026-09-13 14:00:00',
    reporterName: 'Ananya Patel',
    reporterContact: '9812345678'
  }
];

export const INITIAL_CLAIMS: Claim[] = [
  {
    claimId: 1,
    itemId: 5,
    claimantId: 1,
    message: 'This is my Boat smartwatch. The wallpaper is a golden retriever picture and screen lock code ends in 49.',
    status: 'PENDING',
    createdAt: '2026-09-15 16:30:00',
    itemName: 'Black smartwatch',
    itemType: 'FOUND',
    claimantName: 'Rahul Sharma',
    claimantEmail: 'rahul.sharma@campus.edu',
    claimantStudentId: 'STU202601'
  }
];
